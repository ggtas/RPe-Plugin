/*     */ package com.Alvaeron.player;

import com.Alvaeron.Engine;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;

import java.util.*;

public class RoleplayPlayer {

    UUID uuid;
    String playerName;

    public String name = "NONE";
    public String race = "NONE";
    public String nation = "NONE";
    Gender gender = Gender.NONE;
    List<String> skills = new ArrayList<>();
    public int age = 0;
    public String desc = "NONE";
    Channel channel = Channel.RP;
    boolean OOC = false;
    boolean online = true;
    String lang = "";
    public boolean spyEnabled = false;
    public RoleplayPlayer(UUID uuid) {
        this.uuid = uuid;
    }

    public RoleplayPlayer(UUID uuid, String name, int age, String desc,
                          Gender gender, String race) {

        this.uuid = uuid;
        this.name = name;
        this.age = age;
        this.desc = desc;
        this.gender = gender;
        this.race = race;



    }



    public UUID getUuid() { return uuid; }
    public String getName() { return name; }
    public String getRace() { return race; }
    public String getNation() { return nation; }
    public Gender getGender() { return gender; }
    public List<String> getSkills() { return skills; }
    public int getAge() {
        return age;
    }
    public String getDesc() { return desc; }

    public Player getPlayer() {
        return Bukkit.getPlayer(uuid);
    }

    /* -------------------- Skills vs Languages -------------------- */

    public List<String> getLanguages() {

        if (Engine.getInstance().getConfig().getConfigurationSection("Languages") == null)
            return Collections.emptyList();

        Set<String> availableLanguages = Engine.getInstance().getConfig()
                .getConfigurationSection("Languages")
                .getKeys(false);

        List<String> langs = new ArrayList<>();

        for (String skill : skills) {
            if (availableLanguages.contains(skill)) {
                langs.add(skill);
            }
        }


        return langs;
    }

    public List<String> getNormalSkills() {

        if (Engine.getInstance().getConfig().getConfigurationSection("Languages") == null)
            return skills;

        Set<String> availableLanguages = Engine.getInstance().getConfig()
                .getConfigurationSection("Languages")
                .getKeys(false);

        List<String> normal = new ArrayList<>();

        for (String skill : skills) {
            if (!availableLanguages.contains(skill)) {
                normal.add(skill);
            }
        }

        return normal;
    }

    /* -------------------- Setters -------------------- */

    public void setName(String name) {

        Bukkit.getLogger().info("SETNAME CALLED → " + name);

        this.name = name;

        Engine.mm.setStringField(uuid, "name", name);

        setTag();
    }

    public void setAge(int age) {

        this.age = age; // 🔥 DAS IST DER GANZE BUGFIX

        Bukkit.getLogger().info("SET AGE CALLED → " + age);

        Engine.mm.setStringField(uuid, "age", String.valueOf(age));
    }
    public void setDesc(String description) {
        this.desc = description;
        Engine.mm.setStringField(uuid, "desc", description);
    }

    public void addSkill(String skill) {
        skills.add(skill);
        Engine.mm.setStringField(uuid, "skills", String.join(",", skills));
    }

    public void removeSkill(String skill) {
        skills.remove(skill);
        Engine.mm.setStringField(uuid, "skills", String.join(",", skills));
    }

    public int getStat(String stat) {

        String value = Engine.mm.getStringField(uuid, "stat_" + stat);

        Bukkit.getLogger().info("READING STAT → " + stat + " = " + value);

        if (value == null) return 0;

        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    public Channel getChannel() {
        return this.channel;
    }

    public boolean isOOC() {
        return this.OOC;
    }

    public void setChannel(Channel channel) {
        Player p = getPlayer();

        if (this.channel == channel) {
            p.sendMessage(ChatColor.YELLOW + "Du bist bereits im Channel: " + ChatColor.WHITE + channel.name());
            return;
        }

        this.channel = channel;

        p.sendMessage(ChatColor.GREEN + "Chat gewechselt zu: " + ChatColor.WHITE + channel.name());
    }

    public void setGender(Gender gender) {
        this.gender = gender;
        Engine.mm.setStringField(this.uuid, "gender", gender.name());
    }



    public void setNation(String nation) {

        this.nation = nation;
        Engine.mm.setStringField(uuid, "nation", nation);

        applyAutoLanguage();
    }

    public void setOOC(boolean ooc) {

        this.OOC = ooc;

        Engine.mm.setStringField(this.uuid, "ooc", ooc ? "1" : "0");

        if (ooc) {
            getPlayer().sendMessage(ChatColor.GREEN + "OOC chat is now ON");
        } else {
            getPlayer().sendMessage(ChatColor.RED + "OOC chat is now OFF");
        }
    }






    public void setTag() {
        Player p = getPlayer();
        if (p == null) return;

        Engine.nametags.setNametag(
                p.getName(),
                Engine.mu.getRaceColour(race) + name.substring(0, Math.min(9, name.length())) + ChatColor.GRAY + " [",
                "] "
        );
    }


    public String getLang() {
        return this.lang;
    }

    public String getLanguage() {
        return this.lang;
    }

    public boolean toggleSocialSpy() {

        Player p = getPlayer();

        if (p == null) return false;

        if (!p.hasPermission("rpengine.socialspy")) {
            this.spyEnabled = false;
            return false;
        }

        this.spyEnabled = !this.spyEnabled;

        Engine.mm.setStringField(this.uuid, "socialspy", this.spyEnabled ? "1" : "0");

        return this.spyEnabled;
    }

    public void setLanguage(String language) {

        String matchedLanguage =
                Engine.mu.containsCaseInsensitive(language, Engine.rpLanguage.getAvailableLanguages());

        if (matchedLanguage == null) {
            getPlayer().sendMessage(ChatColor.RED + "Unknown language.");
            return;
        }

        this.lang = matchedLanguage;

        Engine.mm.setStringField(this.uuid, "lang", matchedLanguage);

        getPlayer().sendMessage(ChatColor.GREEN + "Language set to " + ChatColor.WHITE + matchedLanguage);
    }




    public enum Channel { OOC, RP }
    public enum Gender { MALE, FEMALE, NONE ;
        public String getName() {

            if (this == NONE) return "None";

            return name().charAt(0) + name().substring(1).toLowerCase();
        }
    }

    public void setStat(String stat, int value) {

        if (stat == null) return;

        // Farben entfernen & vereinheitlichen
        stat = ChatColor.stripColor(stat).trim();

        // Erste Letter groß → exakt wie DB
        stat = stat.substring(0, 1).toUpperCase() + stat.substring(1).toLowerCase();

        Engine.mm.setStringField(
                uuid,
                "stat_" + stat,
                String.valueOf(value)
        );

        Engine.getInstance().debug("Updated stat " + stat + " to " + value);
    }
    public void setRace(String race) {

        this.race = race;
        Engine.mm.setStringField(uuid, "race", race);

        applyAutoLanguage();
        setTag();
    }

    private void applyAutoLanguage() {

        if (Engine.getInstance().getConfig().contains("NationLanguages." + nation)) {

            String lang = Engine.getInstance().getConfig()
                    .getString("NationLanguages." + nation);

            if (lang != null) {
                setLanguage(lang);
                return; // Nation hat Priorität
            }
        }

        if (Engine.getInstance().getConfig().contains("RaceLanguages." + race)) {

            String lang = Engine.getInstance().getConfig()
                    .getString("RaceLanguages." + race);

            if (lang != null) {
                setLanguage(lang);
            }
        }
    }


}