package com.Alvaeron.listeners;

import com.Alvaeron.utils.UnderstandingManager;
import org.bukkit.event.*;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.entity.Player;

public class UnderstandingSaveListener implements Listener {

    private final UnderstandingManager manager;

    public UnderstandingSaveListener(UnderstandingManager manager) {
        this.manager = manager;
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {

        Player player = event.getPlayer();

        manager.saveCache(player.getUniqueId());
        manager.clearCache(player.getUniqueId());
    }
}
