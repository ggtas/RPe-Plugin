package com.Alvaeron.listeners;

import com.Alvaeron.Engine;
import com.Alvaeron.player.RoleplayPlayer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

public class ChatInputListener implements Listener {

    @EventHandler
    public void onChat(AsyncPlayerChatEvent e) {

        Player player = e.getPlayer();

        if (!Engine.chatInputs.containsKey(player.getUniqueId()))
            return;

        e.setCancelled(true);

        String msg = e.getMessage();

        Bukkit.getScheduler().runTask(Engine.getInstance(), () -> {

            Engine.chatInputs.remove(player.getUniqueId()).accept(msg);

            RoleplayPlayer rpp = Engine.manager.getPlayer(player.getUniqueId());

            if (rpp != null)
                player.openInventory(Engine.cardGUI.build(rpp));
        });
    }
}