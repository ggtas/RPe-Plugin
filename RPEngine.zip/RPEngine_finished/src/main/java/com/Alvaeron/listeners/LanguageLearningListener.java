package com.Alvaeron.listeners;

import com.Alvaeron.Engine;
import com.Alvaeron.utils.RandomUtil;
import com.Alvaeron.utils.TextTransformUtil;
import org.bukkit.event.*;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.entity.Player;
import com.Alvaeron.utils.UnderstandingManager;

public class LanguageLearningListener implements Listener {

    private final UnderstandingManager understandingManager;
    private final Engine plugin;


    public LanguageLearningListener(Engine plugin, UnderstandingManager understandingManager) {
        this.plugin = plugin;
        this.understandingManager = understandingManager;
    }

    @EventHandler
    public void onChat(AsyncPlayerChatEvent event) {
        Player sender = event.getPlayer();
        String language = detectLanguage(sender);

        if (language == null) return;

        event.getRecipients().forEach(recipient -> {
            double understanding = understandingManager.getUnderstanding(recipient.getUniqueId(), language);

            if (understanding < 40) {
                recipient.sendMessage(TextTransformUtil.heavy(event.getMessage()));
            } else if (understanding < 80) {
                recipient.sendMessage(TextTransformUtil.partial(event.getMessage()));
            } else {
                recipient.sendMessage(event.getMessage());
            }

            double increment = RandomUtil.between(0.5, 2.0);
            understandingManager.addUnderstanding(recipient.getUniqueId(), language, increment);
        });

        event.setCancelled(true);
    }

    private String detectLanguage(Player sender) {

        if (Engine.manager.getPlayer(sender.getUniqueId()) == null)
            return null;

        return Engine.manager.getPlayer(sender.getUniqueId()).getLanguage();
    }
}