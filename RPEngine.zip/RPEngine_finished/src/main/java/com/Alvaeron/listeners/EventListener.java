package com.Alvaeron.listeners;

import com.Alvaeron.Engine;
import com.Alvaeron.player.RoleplayPlayer;
import com.Alvaeron.utils.LetterRenderer;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityCombustEvent;
import org.bukkit.event.entity.ItemDespawnEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.server.MapInitializeEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.MapMeta;
import org.bukkit.map.MapRenderer;
import org.bukkit.map.MapView;

public class EventListener implements Listener {

    private final Engine plugin;
    public boolean chatEnabled = true;

    public EventListener(Engine plugin) {
        this.plugin = plugin;
        this.chatEnabled = plugin.getConfig().getBoolean("chatEnabled", true);
    }

    /* ========================================================= */
    /* OOC CHAT                                                  */
    /* ========================================================= */

    @EventHandler
    public void onOOCChat(AsyncPlayerChatEvent event) {

        if (event.isCancelled() || !chatEnabled) return;

        Player player = event.getPlayer();
        RoleplayPlayer rpp = Engine.manager.getPlayer(player.getUniqueId());

        if (rpp == null) return; // ✅ Crashschutz

        if (rpp.getChannel() != RoleplayPlayer.Channel.OOC) return;

        String message = event.getMessage();
        String format;

        format = ChatColor.WHITE + "[OOC] " + player.getDisplayName() + ": %2$s";

        if (player.hasPermission("rpengine.chat.color")) {
            message = ChatColor.translateAlternateColorCodes('&', message);
        }

        event.setMessage(message);
        event.setFormat(format);
    }

    /* ========================================================= */
    /* RP CHAT                                                   */
    /* ========================================================= */

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onRPChat(AsyncPlayerChatEvent event) {

        if (event.isCancelled() || !chatEnabled) return;

        Player player = event.getPlayer();
        RoleplayPlayer rpp = Engine.manager.getPlayer(player.getUniqueId());

        if (rpp == null) return; // ✅ Wichtig!

        if (rpp.getChannel() != RoleplayPlayer.Channel.RP) return;

        String message = event.getMessage();
        String format = ChatColor.WHITE + rpp.getName() + ": %2$s";

        event.setMessage(message);
        event.setFormat(format);
    }

    /* ========================================================= */
    /* SHIFT RIGHT CLICK PLAYER                                  */
    /* ========================================================= */

    @EventHandler
    public void shiftRightClick(PlayerInteractEntityEvent event) {

        if (!(event.getRightClicked() instanceof Player)) return;

        Player clicked = (Player) event.getRightClicked();
        Player receiver = event.getPlayer();

        RoleplayPlayer rpp = Engine.manager.getPlayer(clicked.getUniqueId());
        if (rpp == null) return;

        if (receiver.isSneaking()) {
            Engine.card.sendCardOther(rpp, receiver);
        }
    }

    /* ========================================================= */
    /* JOIN                                                      */
    /* ========================================================= */

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {

        Player player = event.getPlayer();

        if (Engine.mm != null) {
            Engine.mm.createRoleplayPlayer(player);
        }
    }

    /* ========================================================= */
    /* LETTER COLLECTION                                         */
    /* ========================================================= */

    @EventHandler
    public void onCollectLetter(PlayerInteractEntityEvent event) {

        Entity entity = event.getRightClicked();

        if (!plugin.birdMessages.containsKey(entity.getUniqueId())) return;

        String message = plugin.birdMessages.get(entity.getUniqueId());

        MapView mapView = Bukkit.createMap(Bukkit.getWorlds().get(0));

        for (MapRenderer renderer : mapView.getRenderers()) {
            mapView.removeRenderer(renderer);
        }

        mapView.addRenderer(new LetterRenderer(message));

        ItemStack mapItem = new ItemStack(Material.MAP, 1);
        MapMeta meta = (MapMeta) mapItem.getItemMeta();

        if (meta != null) {
            meta.setMapId(mapView.getId());
            mapItem.setItemMeta(meta);
        }

        event.getPlayer().getInventory().addItem(mapItem);

        plugin.birdMessages.remove(entity.getUniqueId());
        entity.remove();

        Engine.mm.saveMap(mapView.getId(), message);
    }

    /* ========================================================= */
    /* MAP INIT                                                  */
    /* ========================================================= */

    @EventHandler
    public void onMapInitialise(MapInitializeEvent event) {
        Engine.mm.loadMap(event.getMap());
    }

    /* ========================================================= */
    /* MAP CLEANUP                                               */
    /* ========================================================= */

    @EventHandler
    public void onMapDespawned(ItemDespawnEvent event) {
        removeMapFromDatabase(event.getEntity());
    }

    @EventHandler
    public void onMapBurned(EntityCombustEvent event) {
        if (event.getEntity() instanceof Item) {
            removeMapFromDatabase((Item) event.getEntity());
        }
    }

    private void removeMapFromDatabase(Item item) {

        if (item == null) return;

        ItemStack stack = item.getItemStack();
        if (stack == null || stack.getType() != Material.MAP) return;

        if (!(stack.getItemMeta() instanceof MapMeta)) return;

        MapMeta meta = (MapMeta) stack.getItemMeta();

        if (!meta.hasMapId()) return;

        int mapId = meta.getMapId();

        Engine.mm.removeMap(mapId);
    }
}
    /*     */


/* Location:              C:\Users\Anwender\Downloads\RPEngine-4.6_1.13.jar!\com\Alvaeron\listeners\EventListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */