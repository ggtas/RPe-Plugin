package com.Alvaeron.listeners;

import com.Alvaeron.Engine;
import com.Alvaeron.player.RoleplayPlayer;
import com.Alvaeron.utils.Lang;
import java.util.*;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

public class SocialListener implements Listener {

    private final Engine plugin;
    private final boolean spyEnabled;
    private final boolean chatEnabled;

    private final List<String> socialCmds = Arrays.asList("msg", "m", "t", "pm", "emsg", "epm", "tell", "etell");
    private final List<String> replyCmds = Arrays.asList("r", "er", "reply", "ereply");
    private final List<String> whisperCmds = Arrays.asList("whisper", "w");
    private final List<String> shoutCmds = Arrays.asList("shout", "s");

    public SocialListener(Engine plugin) {
        this.plugin = plugin;
        this.spyEnabled = plugin.getConfig().getBoolean("socialSpy", false);
        this.chatEnabled = plugin.getConfig().getBoolean("chatEnabled", true);
    }

    // ---------------------------------------------------------
    // COMMAND SPY HANDLING
    // ---------------------------------------------------------

    @EventHandler(priority = EventPriority.MONITOR)
    public void onCmd(PlayerCommandPreprocessEvent e) {

        if (e.isCancelled()) return;

        Player sender = e.getPlayer();
        String[] args = e.getMessage().replaceFirst("/", "").split(" ");

        if (args.length == 0) return;

        String cmd = args[0].toLowerCase();

        if (socialCmds.contains(cmd) && args.length >= 2) {

            Player recipient = Bukkit.getPlayer(args[1]);
            if (recipient == null) return;

            String message = String.join(" ", Arrays.copyOfRange(args, 2, args.length));

            plugin.lastMsg.put(sender.getUniqueId(), recipient.getUniqueId());
            plugin.lastMsg.put(recipient.getUniqueId(), sender.getUniqueId());

            sendSocialSpyMsg(sender,
                    Lang.SOCIALSPY_MSG_FORMAT.toString()
                            .replace("%s", sender.getName())
                            .replace("%r", recipient.getName())
                            .replace("%m", message)
            );
        }
    }

    // ---------------------------------------------------------
    // RP CHAT SPY HANDLING (FIXED)
    // ---------------------------------------------------------

    @EventHandler(priority = EventPriority.MONITOR)
    public void onChat(AsyncPlayerChatEvent e) {

        if (e.isCancelled()) return;
        if (!this.chatEnabled) return;

        Player player = e.getPlayer();
        RoleplayPlayer rpp = Engine.manager.getPlayer(player.getUniqueId());

        if (rpp == null) return;
        if (rpp.getChannel() != RoleplayPlayer.Channel.RP) return;

        String message = e.getMessage();
        String format = e.getFormat();

        boolean showPrefix = plugin.getConfig().getBoolean("showPrefixInRPChat", true);

        String name = showPrefix
                ? player.getDisplayName()      // Prefix / Permissions Plugins
                : rpp.getName();               // Charaktername

        sendSocialSpyMsg(player,
                String.format(format, name, message)
        );
    }

    // ---------------------------------------------------------
    // SOCIAL SPY CORE (SAFE)
    // ---------------------------------------------------------

    private void sendSocialSpyMsg(Player sender, String message) {

        for (Player p : Bukkit.getOnlinePlayers()) {

            if (sender.equals(p)) continue;

            RoleplayPlayer rpp = Engine.manager.getPlayer(p.getUniqueId());
            if (rpp == null) continue;

            boolean hasPermission =
                    p.hasPermission("rpengine.socialspy") ||
                            p.hasPermission("rpengine.admin");

            if (spyEnabled && hasPermission && rpp.spyEnabled)  {
                p.sendMessage(ChatColor.DARK_RED + "[Spy] "
                        + ChatColor.GRAY
                        + ChatColor.stripColor(message));
            }
        }
    }
}


