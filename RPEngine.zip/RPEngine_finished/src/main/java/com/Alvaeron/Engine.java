package com.Alvaeron;

import com.Alvaeron.commands.*;
import com.Alvaeron.listeners.*;
import com.Alvaeron.nametags.NametagManager;
import com.Alvaeron.nametags.Utils;
import com.Alvaeron.player.PlayerManager;
import com.Alvaeron.player.RoleplayPlayer;
import com.Alvaeron.utils.*;
import com.Alvaeron.utils.Lang;

import net.milkbowl.vault.chat.Chat;
import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.permission.Permission;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashMap;
import java.util.UUID;
import org.bukkit.configuration.file.YamlConfiguration;
import java.io.File;
import java.util.logging.Level;

public class Engine extends JavaPlugin {

    public static Engine instance;

    public static MessageUtil mu;
    public static MySQLManager mm;
    public static PlayerManager manager;
    public static NametagManager nametags;
    public static Utils utils;
    public static RPLanguage rpLanguage;
    public static Card card;

    private CardGUIListener cardListener;
    public static Economy econ;
    public static Permission perms;
    public static Chat chat;
    public static EventListener listener;
    public static YamlConfiguration LANG;
    public static StatsGUI statsGUI;
    public static CharackterCardGUI cardGUI;
    public static SelectionGUI selectionGUI;
    public static RaceSelectionGUI raceSelectionGUI;
    public static NationSelectionGUI nationSelectionGUI;
    public static HashMap<UUID, java.util.function.Consumer<String>> anvilActions = new HashMap<>();
    public static HashMap<UUID, java.util.function.Consumer<String>> chatInputs = new HashMap<>();


    public static boolean skillsEnabled = false;

    public HashMap<UUID, UUID> lastMsg = new HashMap<>();
    public HashMap<UUID, String> birdMessages = new HashMap<>();

    private UnderstandingManager understandingManager;

    @Override
    public void onEnable() {

        instance = this;

        saveDefaultConfig();
        loadLang();
        cardListener = new CardGUIListener();


        manager = new PlayerManager(this);

        mu = new MessageUtil(this);
        utils = new Utils(this);
        rpLanguage = new RPLanguage(this);
        card = new Card(this);
        nametags = new NametagManager(this);

        cardGUI = new CharackterCardGUI(this);
        statsGUI = new StatsGUI();

        mm = new MySQLManager(this);
        raceSelectionGUI = new RaceSelectionGUI();
        nationSelectionGUI = new NationSelectionGUI();

        mm.onEnable();
        mm.initTables();

        registerEvents();
        loadCommands();
        setupVault();



        skillsEnabled = !getConfig().getStringList("Skills").isEmpty();

        understandingManager = new UnderstandingManager(mm);

        Bukkit.getPluginManager().registerEvents(
                new LanguageLearningListener(this, understandingManager),
                this
        );

        Bukkit.getPluginManager().registerEvents(
                new UnderstandingSaveListener(understandingManager),
                this
        );

        for (Player pl : Bukkit.getOnlinePlayers()) {
            mm.createRoleplayPlayer(pl);
        }

        getLogger().info("RPEngine enabled.");
    }

    @Override
    public void onDisable() {
        if (mm != null) mm.onDisable();
    }

    public RoleplayPlayer getRoleplayPlayer(Player player) {
        return manager.getPlayer(player.getUniqueId());
    }

    public void disablePlugin() {
        setEnabled(false);
    }

    private void registerEvents() {

        Bukkit.getPluginManager().registerEvents(manager, this);

        listener = new EventListener(this);          // ⭐⭐⭐ WICHTIG
        Bukkit.getPluginManager().registerEvents(listener, this);

        Bukkit.getPluginManager().registerEvents(new SocialListener(this), this);
        Bukkit.getPluginManager().registerEvents(new CardGUIListener(), this);
        Bukkit.getPluginManager().registerEvents(new ChatInputListener(), this);
    }

    private void loadCommands() {

        registerCommand("card", new CardCommand(this));
        registerCommand("roll", new RollCommand(this));
        registerCommand("bird", new BirdCommand(this));
        registerCommand("countdown", new CountdownCommand(this));
        registerCommand("rpengine", new RPEngineCommand(this));
        registerCommand("spawnpoint", new SpawnPointCommand(this));

        ChatCommands ch = new ChatCommands(this);

        registerCommand("whisper", ch);
        registerCommand("shout", ch);
        registerCommand("RP", ch);
        registerCommand("OOC", ch);
        registerCommand("toggleooc", ch);
        registerCommand("speak", ch);
        registerCommand("socialspy", ch);
    }

    private void registerCommand(String name, Object executor) {

        if (getCommand(name) == null) {
            getLogger().warning("Missing command in plugin.yml: " + name);
            return;
        }

        getCommand(name).setExecutor((org.bukkit.command.CommandExecutor) executor);
    }

    private void setupVault() {

        if (getServer().getPluginManager().getPlugin("Vault") == null) {
            getLogger().warning("Vault not found.");
            return;
        }

        setupEconomy();
        setupPermissions();
        setupChat();
    }

    private boolean setupEconomy() {
        RegisteredServiceProvider<Economy> rsp =
                getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp == null) return false;
        econ = rsp.getProvider();
        return econ != null;
    }

    private boolean setupPermissions() {
        RegisteredServiceProvider<Permission> rsp =
                getServer().getServicesManager().getRegistration(Permission.class);
        if (rsp == null) return false;
        perms = rsp.getProvider();
        return perms != null;
    }

    private boolean setupChat() {
        RegisteredServiceProvider<Chat> rsp =
                getServer().getServicesManager().getRegistration(Chat.class);
        if (rsp == null) return false;
        chat = rsp.getProvider();
        return chat != null;
    }

    public static Engine getInstance() {
        return instance;
    }



    public void debug(String msg) {
        if (getConfig().getBoolean("debug", false)) {
            getLogger().info("[DEBUG] " + msg);
        }
    }
    public void loadLang() {

        File langFile = new File(getDataFolder(), "lang.yml");

        if (!langFile.exists()) {
            saveResource("lang.yml", false);
        }

        LANG = YamlConfiguration.loadConfiguration(langFile);

        for (Lang item : Lang.values()) {
            if (LANG.getString(item.getPath()) == null) {
                LANG.set(item.getPath(), item.getDefault());
            }
        }

        try {
            LANG.save(langFile);
        } catch (Exception e) {
            getLogger().log(Level.WARNING, "Could not save lang.yml", e);
        }

        Lang.setFile(LANG);
    }

}