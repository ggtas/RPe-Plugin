/*     */ package com.Alvaeron.commands;

import com.Alvaeron.Engine;
import com.Alvaeron.player.RoleplayPlayer;
import com.Alvaeron.utils.Lang;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.Set;

public class ChatCommands extends AbstractCommand implements CommandExecutor {

    public ChatCommands(Engine plugin) {
        super(plugin, new AbstractCommand.Senders[]{AbstractCommand.Senders.PLAYER});
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender,
                             @NotNull Command cmd,
                             @NotNull String label,
                             @NotNull String[] args) {

        return handleCommand(sender, cmd, label, args);
    }

    public boolean handleCommand(CommandSender sender, Command cmd, String commandLabel, String[] args) {
        RoleplayPlayer rpp = Engine.manager.getPlayer(((Player) sender).getUniqueId());

        if (rpp == null) {
            sender.sendMessage(ChatColor.RED + "RoleplayPlayer not loaded yet.");
            return true;
        }

        this.rpp = rpp;
        this.player = (Player) sender;



        if (!Engine.listener.chatEnabled) {
            this.rpp.getPlayer().sendMessage(Lang.CHAT_DISABLED.toString());
            return true;
        }

        if (cmd.getName().equalsIgnoreCase("RP")) {
            this.rpp.setChannel(RoleplayPlayer.Channel.RP);
            this.rpp.setTag();
            return true;
        }

        if (cmd.getName().equalsIgnoreCase("OOC")) {
            if (!this.rpp.isOOC()) {
                this.rpp.setOOC(true);
            }
            this.rpp.setChannel(RoleplayPlayer.Channel.OOC);
            this.rpp.setTag();
            return true;
        }

        if (cmd.getName().equalsIgnoreCase("toggleooc")) {
            this.rpp.setOOC(!this.rpp.isOOC());
            this.rpp.setChannel(RoleplayPlayer.Channel.RP);
            this.rpp.setTag();
            return true;
        }

        if (cmd.getName().equalsIgnoreCase("whisper")) {

            if (args.length < 1) {
                this.player.sendMessage(
                        Lang.CHAT_WHISPER_USAGE.toString()
                                .replace("%c", commandLabel.toLowerCase())
                );
                return true;
            }

            String message = String.join(" ", args);

            Engine.mu.sendRangedMessage(
                    this.player,
                    Lang.CHAT_WHISPER_FORMAT.toString()
                            .replace("%m", message)
                            .replace("%n", this.rpp.getName()),
                    "whisperRange"
            );

            return true;
        }

        if (cmd.getName().equalsIgnoreCase("shout")) {

            if (args.length < 1) {
                this.player.sendMessage(
                        Lang.CHAT_SHOUT_USAGE.toString()
                                .replace("%c", commandLabel.toLowerCase())
                );
                return true;
            }

            String message = String.join(" ", args);

            Engine.mu.sendRangedMessage(
                    this.player,
                    Lang.CHAT_SHOUT_FORMAT.toString()
                            .replace("%m", message)
                            .replace("%n", this.rpp.getName()),
                    "shoutRange"
            );

            return true;
        }

        if (cmd.getName().equalsIgnoreCase("speak")) {

            Set<String> availableLanguages = Engine.rpLanguage.getAvailableLanguages();

            if (args.length < 1) {
                Engine.rpLanguage.sendLanguages(this.rpp);
                return true;
            }

            String inputLang = String.join(" ", args);

            if (Engine.mu.containsCaseInsensitive(inputLang, availableLanguages) != null) {
                this.rpp.setLanguage(inputLang);
            } else {
                Engine.rpLanguage.sendLanguages(this.rpp);
            }

            return true;
        }

        if (cmd.getName().equalsIgnoreCase("socialspy")) {

            boolean spyEnabled = this.rpp.toggleSocialSpy();

            if (spyEnabled) {
                this.player.sendMessage(ChatColor.DARK_RED + "SocialSpy was enabled.");
            } else {
                this.player.sendMessage(ChatColor.DARK_RED + "SocialSpy was disabled.");
            }

            return true;
        }

        return false;
    }
}