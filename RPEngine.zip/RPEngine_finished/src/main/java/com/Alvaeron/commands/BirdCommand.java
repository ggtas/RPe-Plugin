package com.Alvaeron.commands;

import com.Alvaeron.Engine;
import com.Alvaeron.utils.Lang;
import com.Alvaeron.player.RoleplayPlayer;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.entity.Tameable;
import org.bukkit.command.CommandSender;
import org.bukkit.util.Vector;

public class BirdCommand extends AbstractCommand {

    public BirdCommand(Engine plugin) {
        super(plugin);
    }

    @Override
    public boolean handleCommand(CommandSender sender,
                                 org.bukkit.command.Command cmd,
                                 String commandLabel,
                                 String[] args) {

        if (!(sender instanceof Player)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }

        Player player = (Player) sender;

        if (args.length < 2) {
            player.sendMessage(Lang.BIRD_USAGE.toString());
            return true;
        }

        Player target = Bukkit.getPlayer(args[0]);

        if (target == null) {
            player.sendMessage(Lang.BIRD_LOST.toString());
            return true;
        }

        RoleplayPlayer targetPlayer = Engine.manager.getPlayer(target.getUniqueId());

        if (targetPlayer == null) {
            player.sendMessage(Lang.BIRD_LOST.toString());
            return true;
        }

        String message = String.join(" ", args).substring(args[0].length()).trim();

        World playerWorld = target.getWorld();

        player.sendMessage(
                Lang.BIRD_SENT.toString()
                        .replace("%n", Engine.mu.getRaceColour(targetPlayer.getRace()) + targetPlayer.getName())
                        .replace("%p", target.getName())
        );

        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {

            if (!target.isOnline()) {
                player.sendMessage(Lang.BIRD_LOST.toString());
                return;
            }

            target.sendMessage(Lang.BIRD_LAND.toString());

            Location parrotSpawn = new Location(
                    playerWorld,
                    target.getLocation().getX(),
                    target.getLocation().getY() + 2.0D,
                    target.getLocation().getZ()
            );

            Tameable parrot = (Tameable) playerWorld.spawnEntity(parrotSpawn, EntityType.PARROT);

            parrot.setTamed(true);
            parrot.setOwner(target);
            parrot.setVelocity(new Vector(0.5D, 0.5D, 0.5D));

            String truncatedMessage = message.substring(0, Math.min(message.length(), 300)).trim();

            plugin.birdMessages.put(parrot.getUniqueId(), truncatedMessage);

            player.sendMessage(Lang.BIRD_DELIVER.toString());

        }, 20L * 3); // 3 Sekunden Delay (anpassen wenn gewünscht)

        return true;
    }
}




/* Location:              C:\Users\Anwender\Downloads\RPEngine-4.6_1.13.jar!\com\Alvaeron\commands\BirdCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */