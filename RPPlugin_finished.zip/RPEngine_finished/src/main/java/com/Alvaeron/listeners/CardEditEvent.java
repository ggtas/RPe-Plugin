/*    */ package com.Alvaeron.listeners;
/*    */ 
         import com.Alvaeron.player.RoleplayPlayer;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ public class CardEditEvent
/*    */   extends Event
/*    */ {
/* 11 */   private CardField cardField = null;
/* 12 */   private String stringValue = null;
/* 13 */   private int intValue = 0;
/* 14 */   private RoleplayPlayer.Gender gender = null;
/* 15 */   private Player p = null;
/* 16 */   private RoleplayPlayer rpp = null;
/*    */   private boolean cancelled = false;
/*    */   
/*    */   public CardEditEvent(CardField cardField, String value, Player p, RoleplayPlayer rpp) {
/* 20 */     this.cardField = cardField;
/* 21 */     this.stringValue = value;
/* 22 */     this.p = p;
/* 23 */     this.rpp = rpp;
/*    */   }
/*    */   public CardEditEvent(CardField cardField, int value, Player p, RoleplayPlayer rpp) {
/* 26 */     this.cardField = cardField;
/* 27 */     this.intValue = value;
/* 28 */     this.p = p;
/* 29 */     this.rpp = rpp;
/*    */   }
/*    */   public CardEditEvent(CardField cardField, RoleplayPlayer.Gender value, Player p, RoleplayPlayer rpp) {
/* 32 */     this.cardField = cardField;
/* 33 */     this.gender = value;
/* 34 */     this.p = p;
/* 35 */     this.rpp = rpp;
/*    */   }
/*    */   
/*    */   public enum CardField {
/* 39 */     NAME, AGE, GENDER, RACE, NATION, DESC, SKILLS;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getStringValue() {
/* 44 */     return this.stringValue;
/*    */   }
/*    */   public int getIntValue() {
/* 47 */     return this.intValue;
/*    */   }
/*    */   public RoleplayPlayer.Gender getGender() {
/* 50 */     return this.gender;
/*    */   }
/*    */   public CardField getCardField() {
/* 53 */     return this.cardField;
/*    */   }
/*    */   public Player getPlayer() {
/* 56 */     return this.p;
/*    */   }
/*    */   public RoleplayPlayer getRoleplayPlayer() {
/* 59 */     return this.rpp;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setStringValue(String value) {
/* 64 */     this.stringValue = value;
/*    */   }
/*    */   public void setIntValue(int value) {
/* 67 */     this.intValue = value;
/*    */   }
/*    */   public void setGender(RoleplayPlayer.Gender value) {
/* 70 */     this.gender = value;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isCancelled() {
/* 76 */     return this.cancelled;
/*    */   }
/*    */   public void setCancelled(boolean cancel) {
/* 79 */     this.cancelled = cancel;
/*    */   }
/*    */ 
/*    */   
/* 83 */   private static final HandlerList handlers = new HandlerList();
/*    */   
/*    */   public HandlerList getHandlers() {
/* 86 */     return handlers;
/*    */   }
/*    */   
/*    */   public static HandlerList getHandlerList() {
/* 90 */     return handlers;
/*    */   }
/*    */ }


/* Location:              C:\Users\Anwender\Downloads\RPEngine-4.6_1.13.jar!\com\Alvaeron\listeners\CardEditEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */