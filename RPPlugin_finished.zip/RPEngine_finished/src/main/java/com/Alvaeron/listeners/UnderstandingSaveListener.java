package com.Alvaeron.listeners;

import com.Alvaeron.utils.UnderstandingManager;
import org.bukkit.event.*;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.entity.Player;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class UnderstandingSaveListener implements Listener {

    private final UnderstandingManager manager;

    public UnderstandingSaveListener(UnderstandingManager manager) {
        this.manager = manager;
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {

        Player player = event.getPlayer();

        manager.saveCache(player.getUniqueId());
        manager.clearCache(player.getUniqueId());
    }


}
