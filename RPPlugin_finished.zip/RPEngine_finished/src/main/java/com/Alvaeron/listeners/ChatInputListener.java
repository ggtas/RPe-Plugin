package com.Alvaeron.listeners;

import com.Alvaeron.Engine;
import com.Alvaeron.player.RoleplayPlayer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

import java.util.UUID;
import java.util.function.Consumer;

public class ChatInputListener implements Listener {

    @EventHandler(priority = EventPriority.LOWEST)
    public void onChat(AsyncPlayerChatEvent e) {

        Player player = e.getPlayer();
        UUID uuid = player.getUniqueId();

        Consumer<String> action = Engine.chatInputs.remove(uuid);

        if (action == null) return;

        e.setCancelled(true);

        String message = e.getMessage();

        Bukkit.getScheduler().runTask(Engine.getInstance(), () -> {

            action.accept(message);

            RoleplayPlayer rpp = Engine.manager.getPlayer(uuid);

            if (rpp != null) {
                player.openInventory(Engine.cardGUI.build(rpp));
            }
        });
    }
}