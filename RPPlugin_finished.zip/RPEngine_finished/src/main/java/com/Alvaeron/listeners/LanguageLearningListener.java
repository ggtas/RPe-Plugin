package com.Alvaeron.listeners;

import com.Alvaeron.Engine;
import com.Alvaeron.player.RoleplayPlayer;
import com.Alvaeron.utils.RandomUtil;
import com.Alvaeron.utils.TextTransformUtil;
import org.bukkit.event.*;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.entity.Player;
import com.Alvaeron.utils.UnderstandingManager;

public class LanguageLearningListener implements Listener {

    private final UnderstandingManager understandingManager;
    private final Engine plugin;


    public LanguageLearningListener(Engine plugin, UnderstandingManager understandingManager) {
        this.plugin = plugin;
        this.understandingManager = understandingManager;
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onChat(AsyncPlayerChatEvent event) {

        Player sender = event.getPlayer();
        RoleplayPlayer rpp = Engine.manager.getPlayer(sender.getUniqueId());

        if (rpp == null) return;

        // ✅ OOC komplett ignorieren
        if (rpp.getChannel() == RoleplayPlayer.Channel.OOC) return;

        String language = detectLanguage(event.getMessage());

        // ✅ Kein Sprachchat → normalen Chat nicht anfassen
        if (language == null) return;

        event.getRecipients().forEach(recipient -> {

            // Sender darf eigene Sprache IMMER lesen
            if (recipient.equals(sender)) return;

            double understanding =
                    understandingManager.getUnderstanding(recipient.getUniqueId(), language);

            if (understanding < 40) {
                recipient.sendMessage(TextTransformUtil.heavy(event.getMessage()));
            } else if (understanding < 80) {
                recipient.sendMessage(TextTransformUtil.partial(event.getMessage()));
            }
        });

        // ✅ KEIN Cancel → SocialListener verarbeitet weiterhin
    }

    private String detectLanguage(String message) {

        if (message == null) return null;

        for (String lang : Engine.getInstance().getConfig().getConfigurationSection("Languages").getKeys(false)) {

            String prefix = Engine.getInstance().getConfig()
                    .getString("Languages." + lang + ".prefix");

            if (prefix == null) continue;

            if (message.startsWith(prefix)) {
                return lang;
            }
        }

        return null;
    }
}