package com.Alvaeron.listeners;

import com.Alvaeron.Engine;
import com.Alvaeron.player.RoleplayPlayer;
import com.Alvaeron.utils.*;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCreativeEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Objects;
import java.util.function.Consumer;

public class CardGUIListener implements Listener {

    @EventHandler
    public void onClick(InventoryClickEvent e) {

        if (!(e.getWhoClicked() instanceof Player player)) return;
        if (e.getClickedInventory() == null) return;

        RoleplayPlayer rpp = Engine.manager.getPlayer(player.getUniqueId());
        if (rpp == null) return;

    /* =========================================================
       CHARACTER GUI
       ========================================================= */

        if (e.getView().getTopInventory().getHolder() instanceof CharacterHolder) {

            e.setCancelled(true);

            if (e.getRawSlot() >= e.getView().getTopInventory().getSize())
                return;

            switch (e.getRawSlot()) {

                case 10 -> {
                    player.closeInventory();
                    player.sendMessage(ChatColor.YELLOW + "Type your new name in chat.");

                    Engine.chatInputs.put(player.getUniqueId(), value -> {
                        rpp.setName(value);
                        player.openInventory(Engine.cardGUI.build(rpp));
                    });
                }

                case 11 -> {

                    Engine.getInstance().debug("AGE CLICK → shift=" + e.isShiftClick());

                    int age = rpp.getAge();

                    int change = e.isShiftClick() ? 10 : 1;

                    if (e.isLeftClick()) {
                        age += change;
                    }

                    if (e.isRightClick()) {
                        age = Math.max(0, age - change);
                    }

                    rpp.setAge(age);

                    Bukkit.getScheduler().runTaskLater(Engine.getInstance(), () ->
                            player.openInventory(Engine.cardGUI.build(rpp)), 1L);
                }

                case 12 -> {
                    player.closeInventory();
                    player.sendMessage(ChatColor.YELLOW + "Type description in chat.");

                    Engine.chatInputs.put(player.getUniqueId(), value -> {
                        rpp.setDesc(value);
                        player.openInventory(Engine.cardGUI.build(rpp));
                    });
                }

                case 13 -> player.openInventory(Engine.raceSelectionGUI.build());
                case 14 -> player.openInventory(Engine.nationSelectionGUI.build());
                case 15 -> {

                    RoleplayPlayer.Gender[] values = RoleplayPlayer.Gender.values();

                    int index = rpp.getGender().ordinal();

                    if (e.isLeftClick()) {
                        index++;
                        if (index >= values.length) index = 0;
                    }

                    if (e.isRightClick()) {
                        index--;
                        if (index < 0) index = values.length - 1;
                    }

                    rpp.setGender(values[index]);

                    Bukkit.getScheduler().runTaskLater(Engine.getInstance(), () ->
                            player.openInventory(Engine.cardGUI.build(rpp)), 1L);
                }
                case 49 -> player.openInventory(Engine.statsGUI.build(rpp));
            }

            return; // ⭐ wichtig → verhindert Doppelverarbeitung
        }

    /* =========================================================
       STATS GUI
       ========================================================= */

        if (e.getView().getTopInventory().getHolder() instanceof StatsHolder) {

            e.setCancelled(true);

            if (e.getRawSlot() >= e.getView().getTopInventory().getSize())
                return;

            ItemStack clicked = e.getCurrentItem();
            if (clicked == null || !clicked.hasItemMeta()) return;

            String stat = ChatColor.stripColor(clicked.getItemMeta().getDisplayName());

            if (e.getRawSlot() == 49) {
                player.openInventory(Engine.cardGUI.build(rpp));
                return;
            }

            if (e.isLeftClick())
                rpp.setStat(stat, rpp.getStat(stat) + 1);

            if (e.isRightClick())
                rpp.setStat(stat, Math.max(0, rpp.getStat(stat) - 1));

            Bukkit.getScheduler().runTaskLater(Engine.getInstance(),
                    () -> player.openInventory(Engine.statsGUI.build(rpp)), 1L);

            return;
        }

    /* =========================================================
       SELECTION GUI
       ========================================================= */

        if (e.getView().getTopInventory().getHolder() instanceof SelectionHolder) {

            e.setCancelled(true);

            if (e.getRawSlot() >= e.getView().getTopInventory().getSize())
                return;

            ItemStack clicked = e.getCurrentItem();
            if (clicked == null || !clicked.hasItemMeta()) return;

            String value = ChatColor.stripColor(clicked.getItemMeta().getDisplayName());

            if (e.getView().getTitle().equalsIgnoreCase("Select Race"))
                rpp.setRace(value);

            if (e.getView().getTitle().equalsIgnoreCase("Select Nation"))
                rpp.setNation(value);

            Bukkit.getScheduler().runTaskLater(Engine.getInstance(),
                    () -> player.openInventory(Engine.cardGUI.build(rpp)), 1L);
        }
    }



    private void handleAction(Player player, RoleplayPlayer rpp, String action) {

        if (action == null) return;

        switch (action.toUpperCase()) {

            case "NAME" -> openAnvil(player, rpp.getName(), rpp::setName);

            case "DESC" -> openAnvil(player, rpp.getDesc(), rpp::setDesc);

            case "AGE" -> {
                rpp.setAge(rpp.getAge() + 1);
                player.openInventory(Engine.cardGUI.build(rpp));
            }

            default -> {
                if (action.startsWith("STAT_ADD_")) {

                    String stat = action.replace("STAT_ADD_", "");

                    int value = rpp.getStat(stat);

                    Engine.mm.setStringField(
                            rpp.getUuid(),
                            "stat_" + stat,
                            String.valueOf(value + 1)
                    );

                    player.openInventory(Engine.cardGUI.build(rpp));
                }
            }
        }
    }

    private void openAnvil(Player player, String text, Consumer<String> action) {

        Inventory inv = Bukkit.createInventory(player, InventoryType.ANVIL, "Edit");

        ItemStack paper = new ItemStack(Material.PAPER);
        ItemMeta meta = paper.getItemMeta();
        meta.setDisplayName(text == null ? "" : text);
        paper.setItemMeta(meta);

        inv.setItem(0, paper);

        Engine.anvilActions.put(player.getUniqueId(), action);
        player.openInventory(inv);
    }

    @EventHandler
    public void onAnvilResult(InventoryClickEvent e) {

        if (!(e.getWhoClicked() instanceof Player player)) return;
        if (e.getInventory().getType() != InventoryType.ANVIL) return;
        if (e.getSlot() != 2) return;

        ItemStack item = e.getCurrentItem();
        if (item == null || !item.hasItemMeta()) return;

        String value = item.getItemMeta().getDisplayName();

        if (Engine.anvilActions.containsKey(player.getUniqueId())) {
            Engine.anvilActions.remove(player.getUniqueId()).accept(value);
        }

        Bukkit.getScheduler().runTaskLater(Engine.getInstance(), () -> {
            RoleplayPlayer rpp = Engine.manager.getPlayer(player.getUniqueId());
            if (rpp != null) {
                player.openInventory(Engine.cardGUI.build(rpp));
            }
        }, 1L);
    }

    private void addStat(Player player, RoleplayPlayer rpp, String stat) {

        int value = rpp.getStat(stat);

        Engine.mm.setStringField(
                rpp.getUuid(),
                "stat_" + stat,
                String.valueOf(value + 1)
        );

        player.openInventory(Engine.statsGUI.build(rpp));
    }

    private void refreshCharacterGUI(Player player, RoleplayPlayer rpp) {
        Bukkit.getScheduler().runTask(Engine.getInstance(), () ->
                player.openInventory(Engine.cardGUI.build(rpp))
        );
    }

    private void refreshStatsGUI(Player player, RoleplayPlayer rpp) {
        Bukkit.getScheduler().runTask(Engine.getInstance(), () ->
                player.openInventory(Engine.statsGUI.build(rpp))
        );
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {

        if (e.getView().getTopInventory().getHolder() instanceof CharacterHolder
                || e.getView().getTopInventory().getHolder() instanceof StatsHolder
                || e.getView().getTopInventory().getHolder() instanceof SelectionHolder) {

            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent e) {

        if (e.getPlayer().getOpenInventory().getTopInventory().getHolder() instanceof CardHolder) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onCreative(InventoryCreativeEvent e) {

        if (e.getView().getTopInventory().getHolder() instanceof CardHolder) {
            e.setCancelled(true);
        }
    }

    private void openChatInput(Player player, String prompt, Consumer<String> action) {

        player.sendMessage(ChatColor.YELLOW + prompt);
        Engine.chatInputs.put(player.getUniqueId(), action);
    }
}