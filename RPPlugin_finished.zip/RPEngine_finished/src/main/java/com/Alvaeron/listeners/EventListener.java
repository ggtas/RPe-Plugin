package com.Alvaeron.listeners;

import com.Alvaeron.Engine;
import com.Alvaeron.player.RoleplayPlayer;
import com.Alvaeron.utils.LetterRenderer;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityCombustEvent;
import org.bukkit.event.entity.ItemDespawnEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.server.MapInitializeEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.MapMeta;
import org.bukkit.map.MapRenderer;
import org.bukkit.map.MapView;

public class EventListener implements Listener {

    private final Engine plugin;
    public boolean chatEnabled = true;

    public EventListener(Engine plugin) {
        this.plugin = plugin;
        this.chatEnabled = plugin.getConfig().getBoolean("chatEnabled", true);
    }

    /* ========================================================= */
    /* OOC CHAT                                                  */
    /* ========================================================= */



    /* ========================================================= */
    /* RP CHAT                                                   */
    /* ========================================================= */



    /* ========================================================= */
    /* SHIFT RIGHT CLICK PLAYER                                  */
    /* ========================================================= */

    @EventHandler
    public void shiftRightClick(PlayerInteractEntityEvent event) {

        if (!(event.getRightClicked() instanceof Player)) return;

        Player clicked = (Player) event.getRightClicked();
        Player receiver = event.getPlayer();

        RoleplayPlayer rpp = Engine.manager.getPlayer(clicked.getUniqueId());
        if (rpp == null) return;

        if (receiver.isSneaking()) {
            Engine.card.sendCardOther(rpp, receiver);
        }
    }

    /* ========================================================= */
    /* JOIN                                                      */
    /* ========================================================= */

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {

        Player player = event.getPlayer();

        if (Engine.mm != null) {
            Engine.mm.createRoleplayPlayer(player);
        }
    }

    /* ========================================================= */
    /* LETTER COLLECTION                                         */
    /* ========================================================= */

    @EventHandler
    public void onCollectLetter(PlayerInteractEntityEvent event) {

        // Nur Papageien behandeln
        if (event.getRightClicked().getType() != EntityType.PARROT) return;

        Entity entity = event.getRightClicked();

        // Nur unsere gespeicherten Bird-Messages
        if (!plugin.birdMessages.containsKey(entity.getUniqueId())) return;

        event.setCancelled(true); // Verhindert normale Interaktion

        Player player = event.getPlayer();
        String message = plugin.birdMessages.get(entity.getUniqueId());

        if (message == null || message.isEmpty()) return;

        // Neue Map erstellen
        MapView mapView = Bukkit.createMap(player.getWorld());

        // Alte Renderer entfernen (wichtig!)
        for (MapRenderer renderer : mapView.getRenderers()) {
            mapView.removeRenderer(renderer);
        }

        // Unseren LetterRenderer hinzufügen
        mapView.addRenderer(new LetterRenderer(message));

        // Map Item erstellen
        ItemStack mapItem = new ItemStack(Material.FILLED_MAP, 1);

        if (mapItem.getItemMeta() instanceof MapMeta meta) {
            meta.setMapView(mapView);
            mapItem.setItemMeta(meta);
        } else {
            return; // Sicherheitsfallback
        }

        // Map ins Inventar geben
        player.getInventory().addItem(mapItem);

        // Bird entfernen
        plugin.birdMessages.remove(entity.getUniqueId());
        entity.remove();

        // Optional speichern
        Engine.mm.saveMap(mapView.getId(), message);

        player.sendMessage("§aThe bird has delivered its message.");
    }

    /* ========================================================= */
    /* MAP INIT                                                  */
    /* ========================================================= */

    @EventHandler
    public void onMapInitialise(MapInitializeEvent event) {
        Engine.mm.loadMap(event.getMap());
    }

    /* ========================================================= */
    /* MAP CLEANUP                                               */
    /* ========================================================= */

    @EventHandler
    public void onMapDespawned(ItemDespawnEvent event) {
        removeMapFromDatabase(event.getEntity());
    }

    @EventHandler
    public void onMapBurned(EntityCombustEvent event) {
        if (event.getEntity() instanceof Item) {
            removeMapFromDatabase((Item) event.getEntity());
        }
    }

    private void removeMapFromDatabase(Item item) {

        if (item == null) return;

        ItemStack stack = item.getItemStack();
        if (stack == null || stack.getType() != Material.MAP) return;

        if (!(stack.getItemMeta() instanceof MapMeta)) return;

        MapMeta meta = (MapMeta) stack.getItemMeta();

        if (!meta.hasMapId()) return;

        int mapId = meta.getMapId();

        Engine.mm.removeMap(mapId);
    }
}
    /*     */


/* Location:              C:\Users\Anwender\Downloads\RPEngine-4.6_1.13.jar!\com\Alvaeron\listeners\EventListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */