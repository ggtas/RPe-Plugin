package com.Alvaeron;

import java.sql.PreparedStatement;

@FunctionalInterface
public interface SQLConsumer {
    void accept(PreparedStatement ps) throws Exception;
}