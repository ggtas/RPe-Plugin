/*    */ package com.Alvaeron.player;
/*    */ 
/*    */ import com.Alvaeron.Engine;
/*    */ import java.util.ArrayList;
/*    */ import java.util.UUID;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.player.PlayerJoinEvent;
/*    */ import org.bukkit.event.player.PlayerQuitEvent;
/*    */ 
/*    */ public class PlayerManager
/*    */   implements Listener
/*    */ {
/*    */   public Engine plugin;
/* 16 */   public ArrayList<RoleplayPlayer> players = new ArrayList<>();
/*    */   
/*    */   public PlayerManager(Engine plugin) {
/* 19 */     this.plugin = plugin;
/*    */   }
/*    */   
/*    */   public RoleplayPlayer getPlayer(UUID uuid) {
/* 23 */     for (RoleplayPlayer p : this.players) {
/* 24 */       if (p.uuid.equals(uuid)) {
/* 25 */         return p;
/*    */       }
/*    */     } 
/* 28 */     return null;
/*    */   }
/*    */   
/*    */   @EventHandler
public void onQuit(PlayerQuitEvent event) {

    RoleplayPlayer rp = getPlayer(event.getPlayer().getUniqueId());

    if (rp != null) {
        rp.online = false;
    }

    clearPlayer(event.getPlayer().getUniqueId());

    Engine.nametags.reset(event.getPlayer().getName());
}
/*    */   
/*    */   public void clearPlayer(UUID u) {
/* 38 */     if (getPlayer(u) != null) {
/* 39 */       this.players.remove(getPlayer(u));
/*    */     }
/*    */   }
/*    */   
/*    */   public void addPlayer(RoleplayPlayer rpp) {
/* 44 */     clearPlayer(rpp.uuid);
/* 45 */     this.players.add(rpp);
/*    */   }
/*    */   
/*    */   @EventHandler
public void onJoin(PlayerJoinEvent event) {

    Player player = event.getPlayer();
    UUID uuid = player.getUniqueId();

    Engine.nametags.sendTeams(player);
    Engine.nametags.reset(player.getName());

    RoleplayPlayer rpp = Engine.manager.getPlayer(uuid);

    if (rpp == null) {
        rpp = new RoleplayPlayer(uuid);
        Engine.manager.addPlayer(rpp);
    }

    Engine.mm.createRoleplayPlayer(player);   // Datensatz sicherstellen
    Engine.mm.loadRoleplayPlayer(rpp);        // ⭐⭐⭐ DAS IST DER FIX
}
/*    */ }


/* Location:              C:\Users\Anwender\Downloads\RPEngine-4.6_1.13.jar!\com\Alvaeron\player\PlayerManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */