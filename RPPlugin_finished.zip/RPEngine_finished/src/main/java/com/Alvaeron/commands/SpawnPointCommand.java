/*     */ package com.Alvaeron.commands;
/*     */ 
/*     */ import com.Alvaeron.Engine;
/*     */ import com.Alvaeron.utils.Lang;
/*     */ import java.util.Set;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.command.Command;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.entity.Player;
/*     */ 
/*     */ 
/*     */ public class SpawnPointCommand
/*     */   extends AbstractCommand
/*     */ {
/*     */   public SpawnPointCommand(Engine plugin) {
/*  18 */     super(plugin, new AbstractCommand.Senders[] { AbstractCommand.Senders.PLAYER });
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean handleCommand(CommandSender sender, Command cmd, String Commandlabel, String[] args) {
/*  23 */     if (cmd.getName().equalsIgnoreCase("spawnpoint")) {
/*  24 */       Player player = (Player)sender;
/*  25 */       String nation = this.rpp.getNation();
/*  26 */       Set<String> nations = this.plugin.getConfig().getConfigurationSection("Nations").getKeys(false);
/*  27 */       StringBuilder sb = new StringBuilder();
/*     */       
/*  29 */       for (String s : nations) {
/*  30 */         sb.append(s);
/*  31 */         sb.append("/");
/*     */       } 
/*     */       
/*  34 */       String nationString = sb.toString().trim();
/*  35 */       String nationList = nationString.substring(0, nationString.length() - 1);
/*     */       
/*  37 */       if (args.length == 1) {
/*     */         
/*  39 */         if (args[0].equalsIgnoreCase("set")) {
/*     */           
/*  41 */           if (player.hasPermission("rpengine.spawnpoint.set.all") || player.isOp()) {
/*  42 */             player.sendMessage(Lang.SPAWNPOINT_SET_USAGE.toString().replace("%n", nationList)
/*  43 */                 .replace("%c", Commandlabel.toLowerCase()));
/*     */           
/*     */           }
/*  46 */           else if (player.hasPermission("rpengine.spawnpoint.set.own")) {
/*  47 */             player.sendMessage(Lang.SPAWNPOINT_SET_USAGE.toString().replace("%n", this.rpp.getNation())
/*  48 */                 .replace("%c", Commandlabel.toLowerCase()));
/*     */           } else {
/*  50 */             player.sendMessage(Lang.NO_PERMS.toString());
/*     */           } 
/*  52 */           return false;
/*     */         } 
/*  54 */         if (Engine.mu.containsCaseInsensitive(args[0], nations) != null) {
/*  55 */           nation = Engine.mu.getValueFromSet(args[0], nations);
/*  56 */           if (nation.equalsIgnoreCase(this.rpp.getNation())) {
/*  57 */             if (!player.hasPermission("rpengine.spawnpoint.others") && !player.isOp() && !player.hasPermission("rpengine.spawnpoint.own")) {
/*  58 */               player.sendMessage(Lang.NO_PERMS.toString());
/*  59 */               return false;
/*     */             }
/*     */           
/*  62 */           } else if (!player.hasPermission("rpengine.spawnpoint.others") && !player.isOp()) {
/*  63 */             player.sendMessage(Lang.NO_PERMS.toString());
/*  64 */             return false;
/*     */           } 
/*     */         } else {
/*     */           
/*  68 */           if (player.hasPermission("rpengine.spawnpoint.others") || player.isOp()) {
/*  69 */             player.sendMessage(Lang.SPAWNPOINT_SET_USAGE.toString().replace("%n", nationList)
/*  70 */                 .replace("%c", Commandlabel.toLowerCase()));
/*  71 */           } else if (player.hasPermission("rpengine.spawnpoint.own")) {
/*  72 */             player.sendMessage(Lang.SPAWNPOINT_SET_USAGE.toString().replace("%n", this.rpp.getNation())
/*  73 */                 .replace("%c", Commandlabel.toLowerCase()));
/*     */           } else {
/*  75 */             player.sendMessage(Lang.NO_PERMS.toString());
/*     */           } 
/*  77 */           return false;
/*     */         }
/*     */       
/*  80 */       } else if (args.length == 2) {
/*  81 */         if (args[0].equalsIgnoreCase("set")) {
/*  82 */           if (Engine.mu.containsCaseInsensitive(args[1], nations) != null) {
/*  83 */             nation = Engine.mu.getValueFromSet(args[1], nations);
/*  84 */             if (nation.equalsIgnoreCase(this.rpp.getNation())) {
/*  85 */               if (!player.hasPermission("rpengine.spawnpoint.set.all") && !player.hasPermission("rpengine.spawnpoint.set.own") && !player.isOp()) {
/*  86 */                 player.sendMessage(Lang.NO_PERMS.toString());
/*  87 */                 return false;
/*     */               }
/*     */             
/*  90 */             } else if (!player.hasPermission("rpengine.spawnpoint.set.all") && !player.isOp()) {
/*  91 */               player.sendMessage(Lang.NO_PERMS.toString());
/*  92 */               return false;
/*     */             } 
/*     */             
/*  95 */             this.plugin.getConfig().set("Nations." + nation + ".spawnX", Double.valueOf(player.getLocation().getX()));
/*  96 */             this.plugin.getConfig().set("Nations." + nation + ".spawnY", Double.valueOf(player.getLocation().getY()));
/*  97 */             this.plugin.getConfig().set("Nations." + nation + ".spawnZ", Double.valueOf(player.getLocation().getZ()));
/*  98 */             this.plugin.getConfig().set("Nations." + nation + ".spawnYaw", Float.valueOf(player.getLocation().getYaw()));
/*  99 */             this.plugin.getConfig().set("Nations." + nation + ".spawnPitch", Float.valueOf(player.getLocation().getPitch()));
/* 100 */             this.plugin.getConfig().set("Nations." + nation + ".spawnWorld", player.getWorld().getName());
/* 101 */             this.plugin.saveConfig();
/* 102 */             player.sendMessage(Lang.SPAWNPOINT_SET.toString()
/* 103 */                 .replace("%n", nation));
/* 104 */             return true;
/*     */           } 
/*     */           
/* 107 */           if (player.hasPermission("rpengine.spawnpoint.set.all") || player.isOp()) {
/* 108 */             player.sendMessage(Lang.SPAWNPOINT_SET_USAGE.toString().replace("%n", nationList)
/* 109 */                 .replace("%c", Commandlabel.toLowerCase()));
/*     */           
/*     */           }
/* 112 */           else if (player.hasPermission("rpengine.spawnpoint.set.own")) {
/* 113 */             player.sendMessage(Lang.SPAWNPOINT_SET_USAGE.toString().replace("%n", this.rpp.getNation())
/* 114 */                 .replace("%c", Commandlabel.toLowerCase()));
/*     */           } else {
/* 116 */             player.sendMessage(Lang.NO_PERMS.toString());
/*     */           } 
/* 118 */           return false;
/*     */         } 
/*     */         
/* 121 */         if (player.hasPermission("rpengine.spawnpoint.set.own") || player.hasPermission("rpengine.spawnpoint.set.all") || player.isOp()) {
/* 122 */           player.sendMessage(Lang.SPAWNPOINT_SET_USAGE.toString().replace("%n", nationList)
/* 123 */               .replace("%c", Commandlabel.toLowerCase()));
/*     */         } else {
/* 125 */           player.sendMessage(Lang.SPAWNPOINT_USAGE.toString().replace("%n", nationList)
/* 126 */               .replace("%c", Commandlabel.toLowerCase()));
/*     */         } 
/* 128 */         return false;
/*     */       } 
/*     */       
/* 131 */       if (nation.equalsIgnoreCase("NONE")) {
/* 132 */         player.sendMessage(Lang.SPAWNPOINT_NO_NATION.toString());
/* 133 */         player.teleport(player.getWorld().getSpawnLocation());
/* 134 */         return false;
/*     */       } 
/* 136 */       Location location = player.getLocation();
/* 137 */       if (this.plugin.getConfig().contains("Nations." + nation + ".spawnX")) {
/* 138 */         location.setX(this.plugin.getConfig().getDouble("Nations." + nation + ".spawnX"));
/*     */       } else {
/* 140 */         player.sendMessage(ChatColor.RED + "Error: " + ChatColor.WHITE + "Something went wrong with retrieving data from the config file");
/* 141 */         return false;
/*     */       } 
/* 143 */       if (this.plugin.getConfig().contains("Nations." + nation + ".spawnY")) {
/* 144 */         location.setY(this.plugin.getConfig().getDouble("Nations." + nation + ".spawnY"));
/*     */       } else {
/* 146 */         player.sendMessage(Lang.SPAWNPOINT_CONFIG_ERROR.toString());
/* 147 */         return false;
/*     */       } 
/* 149 */       if (this.plugin.getConfig().contains("Nations." + nation + ".spawnZ")) {
/* 150 */         location.setZ(this.plugin.getConfig().getDouble("Nations." + nation + ".spawnZ"));
/*     */       } else {
/* 152 */         player.sendMessage(Lang.SPAWNPOINT_CONFIG_ERROR.toString());
/* 153 */         return false;
/*     */       } 
/* 155 */       if (this.plugin.getConfig().contains("Nations." + nation + ".spawnYaw")) {
/* 156 */         location.setYaw((float)this.plugin.getConfig().getDouble("Nations." + nation + ".spawnYaw"));
/*     */       } else {
/* 158 */         player.sendMessage(Lang.SPAWNPOINT_CONFIG_ERROR.toString());
/* 159 */         return false;
/*     */       } 
/* 161 */       if (this.plugin.getConfig().contains("Nations." + nation + ".spawnPitch")) {
/* 162 */         location.setPitch((float)this.plugin.getConfig().getDouble("Nations." + nation + ".spawnPitch"));
/*     */       } else {
/* 164 */         player.sendMessage(Lang.SPAWNPOINT_CONFIG_ERROR.toString());
/* 165 */         return false;
/*     */       } 
/* 167 */       if (this.plugin.getConfig().contains("Nations." + nation + ".spawnWorld")) {
/* 168 */         if (Bukkit.getWorld(this.plugin.getConfig().getString("Nations." + nation + ".spawnWorld")) != null) {
/* 169 */           location.setPitch((float)this.plugin.getConfig().getDouble("Nations." + nation + ".spawnPitch"));
/*     */         } else {
/* 171 */           player.sendMessage(Lang.SPAWNPOINT_CONFIG_ERROR.toString());
/* 172 */           return false;
/*     */         } 
/*     */       } else {
/* 175 */         player.sendMessage(Lang.SPAWNPOINT_CONFIG_ERROR.toString());
/* 176 */         return false;
/*     */       } 
/* 178 */       player.teleport(location);
/* 179 */       player.sendMessage(Lang.SPAWNPOINT_TELEPORT.toString().replace("%n", nation));
/* 180 */       return true;
/*     */     } 
/* 182 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Anwender\Downloads\RPEngine-4.6_1.13.jar!\com\Alvaeron\commands\SpawnPointCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */