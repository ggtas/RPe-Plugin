/*    */ package com.Alvaeron.commands;
/*    */ 
/*    */ import com.Alvaeron.Engine;
/*    */ import com.Alvaeron.commands.AbstractCommand;
         import com.Alvaeron.utils.Lang;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class RPEngineCommand
/*    */   extends AbstractCommand {
/*    */   public RPEngineCommand(Engine plugin) {
/* 13 */     super(plugin, AbstractCommand.Senders.values());
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean handleCommand(CommandSender sender, Command cmd, String Commandlabel, String[] args) {
/* 19 */     if (cmd.getName().equalsIgnoreCase("rpengine")) {
/* 20 */       if (!(sender instanceof Player) || sender.hasPermission("rpengine.admin")) {
/* 21 */         if (args.length == 1) {
/* 22 */           if (args[0].equalsIgnoreCase("reload")) {
/* 23 */             this.plugin.reloadConfig();
/* 24 */             this.plugin.loadLang();
/* 25 */             sender.sendMessage(Lang.TITLE.toString() + Lang.RELOAD);
/* 26 */           } else if (args[0].equalsIgnoreCase("debug")) {
/* 27 */             Engine.manager.players.clear();
/*    */             
/* 29 */             for (Player pl : Bukkit.getOnlinePlayers()) {
/* 30 */               Engine.mm.createRoleplayPlayer(pl);
/*    */             }
/*    */             
/* 33 */             sender.sendMessage("Players recached");
/*    */           } 
/*    */         } else {
/* 36 */           sender.sendMessage(Lang.TITLE.toString() + Lang.VERSION.toString().replace("%v", this.plugin.getDescription().getVersion()));
/*    */         } 
/*    */       } else {
/* 39 */         sender.sendMessage(Lang.NO_PERMS.toString());
/*    */       } 
/* 41 */       return true;
/*    */     } 
/* 43 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\Anwender\Downloads\RPEngine-4.6_1.13.jar!\com\Alvaeron\commands\RPEngineCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */