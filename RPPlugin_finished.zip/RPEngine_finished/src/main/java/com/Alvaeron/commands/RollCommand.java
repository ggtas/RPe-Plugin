/*     */ package com.Alvaeron.commands;
/*     */ 
/*     */ import com.Alvaeron.Engine;
/*     */ import com.Alvaeron.player.RoleplayPlayer;
/*     */ import com.Alvaeron.utils.Lang;
/*     */ import java.util.Random;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.bukkit.command.Command;
/*     */ import org.bukkit.command.CommandSender;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RollCommand
/*     */   extends AbstractCommand
/*     */ {
/*     */   public RollCommand(Engine plugin) {
/*  18 */     super(plugin, AbstractCommand.Senders.values());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean handleCommand(CommandSender sender, Command cmd, String Commandlabel, String[] args) {
/*  24 */     int roll, diceSides = 20;
/*  25 */     int numDice = 1;
/*  26 */     int extra = 0;
/*  27 */     int multiplier = 1;
/*  28 */     boolean multiply = false;
/*     */     
/*  30 */     if (args.length > 1) {
/*  31 */       sender.sendMessage(Lang.ROLL_USAGE.toString());
/*  32 */       return true;
/*     */     } 
/*  34 */     if (args.length == 1) {
/*  35 */       Pattern pattern = Pattern.compile("([1-9]\\d*)?d([1-9]\\d*)([/x][1-9]\\d*)?([+-]\\d+)?");
/*  36 */       Matcher matcher = pattern.matcher(args[0]);
/*  37 */       if (matcher.matches()) {
/*  38 */         numDice = (matcher.group(1) != null) ? Integer.parseInt(matcher.group(1)) : 1;
/*  39 */         diceSides = Integer.parseInt(matcher.group(2));
/*  40 */         if (matcher.group(3) != null) {
/*  41 */           multiply = matcher.group(3).startsWith("x");
/*     */           try {
/*  43 */             multiplier = Integer.parseInt(matcher.group(3).substring(1));
/*  44 */           } catch (NumberFormatException e) {
/*  45 */             sender.sendMessage(Lang.ROLL_USAGE.toString());
/*  46 */             return true;
/*     */           } 
/*     */         } 
/*  49 */         if (matcher.group(4) != null) {
/*  50 */           int val; boolean positive = matcher.group(4).startsWith("+");
/*     */           
/*     */           try {
/*  53 */             val = Integer.parseInt(matcher.group(4).substring(1));
/*  54 */           } catch (NumberFormatException e) {
/*  55 */             sender.sendMessage(Lang.ROLL_USAGE.toString());
/*  56 */             return true;
/*     */           } 
/*  58 */           extra = positive ? val : -val;
/*     */         } 
/*     */       } else {
/*     */         
/*  62 */         sender.sendMessage(Lang.ROLL_USAGE.toString());
/*  63 */         return true;
/*     */       } 
/*     */     } 
/*  66 */     if (diceSides > this.plugin.getConfig().getInt("maxRoll")) {
/*  67 */       sender.sendMessage(Lang.ROLL_MAX.toString().replace("%n", Integer.toString(this.plugin.getConfig().getInt("maxRoll"))));
/*  68 */       return true;
/*     */     } 
/*     */     
/*  71 */     Random diceRoller = new Random();
/*     */     
/*  73 */     if (multiply) {
/*  74 */       roll = numDice * (diceRoller.nextInt(diceSides) + 1) * multiplier + extra;
/*     */     } else {
/*  76 */       roll = numDice * (diceRoller.nextInt(diceSides) + 1) / multiplier + extra;
/*     */     } 
/*  78 */     if (sender instanceof org.bukkit.entity.Player)
/*  79 */     { if (this.rpp.getChannel() == RoleplayPlayer.Channel.RP) {
/*  80 */         Engine.mu.sendRangedMessage(this.player, Lang.ROLL_RESULT
/*  81 */             .toString()
/*  82 */             .replace("%c", this.rpp.getChannel().toString())
/*  83 */             .replace("%r", this.rpp.getPlayer().getName())
/*  84 */             .replace("%n", Integer.toString(roll))
/*  85 */             .replace("%m", (args.length >= 1) ? args[0] : "1d20"), "rpRange");
/*     */       } else {
/*     */         
/*  88 */         this.plugin.getServer().broadcastMessage(Lang.ROLL_RESULT.toString()
/*  89 */             .replace("%c", this.rpp.getChannel().toString())
/*  90 */             .replace("%r", this.rpp.getPlayer().getName())
/*  91 */             .replace("%n", Integer.toString(roll))
/*  92 */             .replace("%m", (args.length >= 1) ? args[0] : "1d20"));
/*     */       }  }
/*  94 */     else { this.plugin.getServer().broadcastMessage(Lang.ROLL_CONSOLE.toString()
/*  95 */           .replace("%c", this.rpp.getChannel().toString())
/*  96 */           .replace("%r", this.rpp.getName())
/*  97 */           .replace("%n", Integer.toString(roll))
/*  98 */           .replace("%m", (args.length >= 1) ? args[0] : "1d20")); }
/*     */     
/* 100 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\Anwender\Downloads\RPEngine-4.6_1.13.jar!\com\Alvaeron\commands\RollCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */