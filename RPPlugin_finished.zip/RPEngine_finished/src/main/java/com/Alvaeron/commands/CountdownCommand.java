/*    */ package com.Alvaeron.commands;
/*    */ 
/*    */ import com.Alvaeron.Engine;
/*    */ import com.Alvaeron.utils.Countdown;
/*    */ import com.Alvaeron.utils.Lang;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class CountdownCommand
/*    */   extends AbstractCommand
/*    */ {
/*    */   public CountdownCommand(Engine plugin) {
/* 14 */     super(plugin, new AbstractCommand.Senders[] { AbstractCommand.Senders.PLAYER });
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean handleCommand(CommandSender sender, Command cmd, String Commandlabel, String[] args) {
/* 20 */     if (args.length == 0) {
/* 21 */       sender.sendMessage(Lang.COUNTDOWN_USAGE.toString());
/*    */     }
/* 23 */     if (args.length == 1) {
/*    */       try {
/* 25 */         int n = Integer.parseInt(args[0]);
/* 26 */         Player player = (Player)sender;
/* 27 */         if (n < 0) {
/* 28 */           player.sendMessage(Lang.COUNTDOWN_NEGATIVE.toString());
/* 29 */         } else if (n <= this.plugin.getConfig().getInt("maxCountdown")) {
/* 30 */           Engine.mu.sendRangedMessage(player, Lang.COUNTDOWN_START
/* 31 */               .toString()
/* 32 */               .replace("%r", this.rpp.getName())
/* 33 */               .replace("%p", this.rpp.getPlayer().getName())
/* 34 */               .replace("%n", Integer.toString(n)), "rpRange");
/*    */           
/* 36 */           Countdown c = new Countdown(this.plugin);
/* 37 */           c.startCountdown(player, true, Integer.parseInt(args[0]));
/*    */         } else {
/* 39 */           player.sendMessage(Lang.COUNTDOWN_MAX.toString().replace("%m", Integer.toString(this.plugin.getConfig().getInt("maxCountdown"))));
/*    */         } 
/* 41 */       } catch (NumberFormatException e) {
/* 42 */         this.player.sendMessage(Lang.COUNTDOWN_USAGE.toString());
/*    */       } 
/*    */     }
/* 45 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Anwender\Downloads\RPEngine-4.6_1.13.jar!\com\Alvaeron\commands\CountdownCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */