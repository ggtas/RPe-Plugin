/*    */ package com.Alvaeron.commands;
/*    */ 
/*    */ import com.Alvaeron.Engine;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandSender;
/*    */ 
/*    */ public class RPCommand
/*    */   extends AbstractCommand {
/*    */   public RPCommand(Engine plugin) {
/* 10 */     super(plugin, new AbstractCommand.Senders[] { AbstractCommand.Senders.PLAYER });
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean handleCommand(CommandSender sender, Command cmd, String Commandlabel, String[] args) {
/* 16 */     if (cmd.getName().equalsIgnoreCase("rp"));
/*    */ 
/*    */     
/* 19 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\Anwender\Downloads\RPEngine-4.6_1.13.jar!\com\Alvaeron\commands\RPCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */