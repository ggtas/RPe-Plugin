/*    */ package com.Alvaeron.commands;
/*    */ 
/*    */ import com.Alvaeron.Engine;
/*    */ import com.Alvaeron.player.RoleplayPlayer;
/*    */ import java.util.Arrays;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractCommand
/*    */   implements CommandExecutor
/*    */ {
/*    */   protected Engine plugin;
/*    */   private Senders[] definedSenders;
/*    */   protected Player player;
/*    */   protected RoleplayPlayer rpp;
/*    */   
/*    */   public AbstractCommand(Engine plugin, Senders... definedSenders) {
/* 30 */     this.plugin = plugin;
/* 31 */     this.definedSenders = definedSenders;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public abstract boolean handleCommand(CommandSender paramCommandSender, Command paramCommand, String paramString, String[] paramArrayOfString);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean onCommand(CommandSender sender, Command cmd, String Commandlabel, String[] args) {
/* 53 */     boolean error = false;
/* 54 */     if (sender instanceof org.bukkit.command.BlockCommandSender) {
/* 55 */       error = !Arrays.<Senders>asList(this.definedSenders).contains(Senders.COMMANDBLOCK);
/*    */     }
/* 57 */     if (sender instanceof org.bukkit.command.ConsoleCommandSender) {
/* 58 */       error = !Arrays.<Senders>asList(this.definedSenders).contains(Senders.CONSOLE);
/*    */     }
/* 60 */     if (sender instanceof Player) {
/* 61 */       error = !Arrays.<Senders>asList(this.definedSenders).contains(Senders.PLAYER);
/* 62 */       this.player = (Player)sender;
/* 63 */       this.rpp = Engine.manager.getPlayer(this.player.getUniqueId());
/*    */     } 
/* 65 */     if (error) {
/* 66 */       sender.sendMessage("This command can only be run by:" + this.definedSenders.toString());
/* 67 */       return false;
/*    */     } 
/* 69 */     return handleCommand(sender, cmd, Commandlabel, args);
/*    */   }
/*    */   
/*    */   public enum Senders {
/* 73 */     CONSOLE, PLAYER, COMMANDBLOCK;
/*    */   }
/*    */ }


/* Location:              C:\Users\Anwender\Downloads\RPEngine-4.6_1.13.jar!\com\Alvaeron\commands\AbstractCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */