/*     */ package com.Alvaeron.commands;

import com.Alvaeron.Engine;
import com.Alvaeron.listeners.CardEditEvent;
import com.Alvaeron.player.RoleplayPlayer;
import com.Alvaeron.utils.Cooldown;
import com.Alvaeron.utils.Lang;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

public class CardCommand extends AbstractCommand {

    public CardCommand(Engine plugin) {
        super(plugin, new AbstractCommand.Senders[]{Senders.PLAYER});
    }

    @Override
    public boolean handleCommand(CommandSender sender, Command cmd, String label, String[] args) {

        // SAFETY CHECK (schadet nie)
        if (!(sender instanceof Player)) {
            sender.sendMessage("Players only.");
            return true;
        }

        Player player = (Player) sender;

        // =========================
        // /card (keine args)
        // =========================
        if (args.length == 0) {
            this.player.openInventory(Engine.cardGUI.build(this.rpp));
            return true;
        }

        // =========================
        // /card stats  ✅ NEU
        // =========================
        if (args[0].equalsIgnoreCase("stats")) {
            player.openInventory(Engine.statsGUI.build(this.rpp));
            return true;
        }

        // =========================
        // /card name
        // =========================
        if (args[0].equalsIgnoreCase("name")) {

            if (args.length < 2) {
                player.sendMessage(Lang.CARD_NAME_USAGE.toString());
                return true;
            }

            if (!cardTime(player, "name")) return true;

            String name = Arrays.stream(args)
                    .skip(1)
                    .collect(Collectors.joining(" "))
                    .replace("\"", "");

            CardEditEvent event = new CardEditEvent(
                    CardEditEvent.CardField.NAME,
                    name,
                    player,
                    this.rpp
            );

            Bukkit.getPluginManager().callEvent(event);

            if (!event.isCancelled()) {
                this.rpp.setName(event.getStringValue());
                this.rpp.setTag();

                player.sendMessage(Lang.CARD_UPDATED_TO.toString()
                        .replace("%f", Lang.CARD_FIELD_NAME.toString())
                        .replace("%v", name));

                Engine.card.clickToSendCard(player);
            }

            return true;
        }

        // =========================
        // /card skills
        // =========================
        if (args[0].equalsIgnoreCase("skills")) {

            if (!Engine.skillsEnabled) {
                player.sendMessage("Skills are disabled.");
                return true;
            }

            if (args.length == 1) {
                Engine.card.sendSkillActionSelect(player);
                return true;
            }

            if (args.length == 2) {
                if (args[1].equalsIgnoreCase("add")) {
                    Engine.card.sendAddSkills(this.rpp);
                } else if (args[1].equalsIgnoreCase("remove")) {
                    Engine.card.sendRemoveSkills(this.rpp);
                } else {
                    Engine.card.sendSkillActionSelect(player);
                }
                return true;
            }

            String inputSkill = Arrays.stream(args)
                    .skip(2)
                    .collect(Collectors.joining(" "));

            Set<String> skills = new HashSet<>(plugin.getConfig().getStringList("Skills"));
            skills.addAll(plugin.getConfig().getConfigurationSection("Languages").getKeys(false));

            if (Engine.mu.containsCaseInsensitive(inputSkill, skills) != null) {

                if (args[1].equalsIgnoreCase("add")) {
                    this.rpp.addSkill(inputSkill);
                } else if (args[1].equalsIgnoreCase("remove")) {
                    this.rpp.removeSkill(inputSkill);
                }

                player.sendMessage(Lang.CARD_UPDATED_TO.toString()
                        .replace("%f", Lang.CARD_FIELD_SKILLS.toString())
                        .replace("%v", String.join(", ", this.rpp.getSkills())));

                Engine.card.clickToSendCard(player);
                this.rpp.setTag();

            } else {
                Engine.card.sendSkillActionSelect(player);
            }

            return true;
        }

        // =========================
        // /card <player>
        // =========================
        Player target = Bukkit.getPlayer(args[0]);

        if (target != null) {
            Engine.card.sendCardOther(
                    Engine.manager.getPlayer(target.getUniqueId()),
                    player
            );
        } else {
            player.sendMessage(Lang.CARD_OFFLINE.toString().replace("%p", args[0]));
        }

        return true;
    }

    private boolean cardTime(Player player, String type) {

        if (!Cooldown.tryCooldown(player, type, plugin.getConfig().getInt("cardCooldown") * 1000L)) {

            long timeLeft = TimeUnit.MILLISECONDS.toMinutes(Cooldown.getCooldown(player, type));

            player.sendMessage(ChatColor.RED +
                    "You must wait " + timeLeft + " minutes before changing your " + type + " again.");

            return false;
        }

        return true;
    }
}


/* Location:              C:\Users\Anwender\Downloads\RPEngine-4.6_1.13.jar!\com\Alvaeron\commands\CardCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */