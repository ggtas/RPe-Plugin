package com.Alvaeron.api;

import com.Alvaeron.Engine;
import com.Alvaeron.player.RoleplayPlayer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import java.util.UUID;

public class RPEngineAPI {

    public static RoleplayPlayer getRoleplayPlayer(Player p) {
        return Engine.manager.getPlayer(p.getUniqueId());
    }

    public static RoleplayPlayer getRoleplayPlayer(UUID uuid) {
        return Engine.manager.getPlayer(uuid);
    }

    public static RoleplayPlayer getRoleplayPlayer(String playerName) {

        Player p = Bukkit.getPlayerExact(playerName);

        if (p == null) return null;

        return Engine.manager.getPlayer(p.getUniqueId());
    }

    /* ==================== GETTER ==================== */

    public static String getRPName(String playerName) {
        RoleplayPlayer rp = getRoleplayPlayer(playerName);
        return rp != null ? rp.getName() : null;
    }

    public static int getAge(String playerName) {
        RoleplayPlayer rp = getRoleplayPlayer(playerName);
        return rp != null ? rp.getAge() : 0;
    }

    public static RoleplayPlayer.Gender getGender(String playerName) {
        RoleplayPlayer rp = getRoleplayPlayer(playerName);
        return rp != null ? rp.getGender() : RoleplayPlayer.Gender.NONE;
    }

    public static String getRace(String playerName) {
        RoleplayPlayer rp = getRoleplayPlayer(playerName);
        return rp != null ? rp.getRace() : null;
    }

    public static String getNation(String playerName) {
        RoleplayPlayer rp = getRoleplayPlayer(playerName);
        return rp != null ? rp.getNation() : null;
    }

    public static String getDescription(String playerName) {
        RoleplayPlayer rp = getRoleplayPlayer(playerName);
        return rp != null ? rp.getDesc() : null;
    }

    public static RoleplayPlayer.Channel getChannel(String playerName) {
        RoleplayPlayer rp = getRoleplayPlayer(playerName);
        return rp != null ? rp.getChannel() : RoleplayPlayer.Channel.RP;
    }

    public static boolean isOOC(String playerName) {
        RoleplayPlayer rp = getRoleplayPlayer(playerName);
        return rp != null && rp.isOOC();
    }

    /* ==================== SETTER ==================== */

    public static void setRPName(String playerName, String name) {
        RoleplayPlayer rp = getRoleplayPlayer(playerName);
        if (rp != null) rp.setName(name);
    }

    public static void setAge(String playerName, int age) {
        RoleplayPlayer rp = getRoleplayPlayer(playerName);
        if (rp != null) rp.setAge(age);
    }

    public static void setGender(String playerName, RoleplayPlayer.Gender gender) {

        RoleplayPlayer rp = getRoleplayPlayer(playerName);

        if (rp == null) return;

        rp.setGender(gender);
    }

    public static void setRace(String playerName, String race) {
        RoleplayPlayer rp = getRoleplayPlayer(playerName);
        if (rp != null) rp.setRace(race);
    }

    public static void setNation(String playerName, String nation) {
        RoleplayPlayer rp = getRoleplayPlayer(playerName);
        if (rp != null) rp.setNation(nation);
    }

    public static void setDescription(String playerName, String desc) {
        RoleplayPlayer rp = getRoleplayPlayer(playerName);
        if (rp != null) rp.setDesc(desc);
    }

    public static void setChannel(String playerName, RoleplayPlayer.Channel channel) {
        RoleplayPlayer rp = getRoleplayPlayer(playerName);
        if (rp != null) rp.setChannel(channel);
    }

    public static void setOOC(String playerName, boolean value) {
        RoleplayPlayer rp = getRoleplayPlayer(playerName);
        if (rp != null) rp.setOOC(value);
    }
}