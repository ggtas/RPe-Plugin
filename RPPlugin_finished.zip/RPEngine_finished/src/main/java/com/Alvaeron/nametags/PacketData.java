package com.Alvaeron.nametags;

public enum PacketData {

    V1_13("members", "prefix", "suffix", "team", "param", "option",
            "displayName", "push", "visibility");

    private final String members;
    private final String prefix;
    private final String suffix;
    private final String teamName;
    private final String paramInt;
    private final String packOption;
    private final String displayName;
    private final String push;
    private final String visibility;

    PacketData(String members, String prefix, String suffix,
               String teamName, String paramInt, String packOption,
               String displayName, String push, String visibility) {

        this.members = members;
        this.prefix = prefix;
        this.suffix = suffix;
        this.teamName = teamName;
        this.paramInt = paramInt;
        this.packOption = packOption;
        this.displayName = displayName;
        this.push = push;
        this.visibility = visibility;
    }

    public String getMembers() { return members; }
    public String getPrefix() { return prefix; }
    public String getSuffix() { return suffix; }
    public String getTeamName() { return teamName; }
    public String getParamInt() { return paramInt; }
    public String getPackOption() { return packOption; }
    public String getDisplayName() {
        return displayName;
    }

    public String getPush() {
        return push;
    }

    public String getVisibility() {
        return visibility;
    }
}
