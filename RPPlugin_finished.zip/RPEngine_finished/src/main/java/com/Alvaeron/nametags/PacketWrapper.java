/*    */ package com.Alvaeron.nametags;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ public class PacketWrapper
/*    */ {
/*    */   public String error;
/* 12 */   private Object packet = PacketAccessor.createPacket();
/*    */   
/*    */   public PacketWrapper(String name, int param, List<String> members) {
/* 15 */     if (param != 3 && param != 4) {
/* 16 */       throw new IllegalArgumentException("Method must be join or leave for player constructor");
/*    */     }
/* 18 */     setupDefaults(name, param);
/* 19 */     setupMembers(members);
/*    */   }
/*    */ 
/*    */   
/*    */   public PacketWrapper(String name, String prefix, String suffix, int param, Collection<?> players) {
/* 24 */     setupDefaults(name, param);
/* 25 */     if (param == 0 || param == 2) {
/*    */       try {
/* 27 */         PacketAccessor.DISPLAY_NAME.set(this.packet, name);
/* 28 */         PacketAccessor.PREFIX.set(this.packet, prefix);
/* 29 */         PacketAccessor.SUFFIX.set(this.packet, suffix);
/* 30 */         PacketAccessor.PACK_OPTION.set(this.packet, Integer.valueOf(1));
/*    */         
/* 32 */         if (PacketAccessor.VISIBILITY != null) {
/* 33 */           PacketAccessor.VISIBILITY.set(this.packet, "always");
/*    */         }
/*    */         
/* 36 */         if (param == 0) {
/* 37 */           ((Collection)PacketAccessor.MEMBERS.get(this.packet)).addAll(players);
/*    */         }
/* 39 */       } catch (Exception e) {
/* 40 */         this.error = e.getMessage();
/*    */       } 
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   private void setupMembers(Collection<?> players) {
/*    */     try {
/* 48 */       players = (players == null || players.isEmpty()) ? new ArrayList() : players;
/* 49 */       ((Collection)PacketAccessor.MEMBERS.get(this.packet)).addAll(players);
/* 50 */     } catch (Exception e) {
/* 51 */       this.error = e.getMessage();
/*    */     } 
/*    */   }
/*    */   
/*    */   private void setupDefaults(String name, int param) {
/*    */     try {
/* 57 */       PacketAccessor.TEAM_NAME.set(this.packet, name);
/* 58 */       PacketAccessor.PARAM_INT.set(this.packet, Integer.valueOf(param));
/* 59 */     } catch (Exception e) {
/* 60 */       this.error = e.getMessage();
/*    */     } 
/*    */   }
/*    */   
/*    */   public void send() {
/* 65 */     PacketAccessor.sendPacket(Utils.getOnline(), this.packet);
/*    */   }
/*    */   
/*    */   public void send(Player player) {
/* 69 */     PacketAccessor.sendPacket(player, this.packet);
/*    */   }
/*    */ }


/* Location:              C:\Users\Anwender\Downloads\RPEngine-4.6_1.13.jar!\com\Alvaeron\nametags\PacketWrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */