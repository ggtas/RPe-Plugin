/*    */ package com.Alvaeron.nametags;
/*    */ 
/*    */ import com.Alvaeron.Engine;
/*    */ import java.io.File;
/*    */ import java.io.FileOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.ChatColor;
/*    */ import org.bukkit.World;
/*    */ import org.bukkit.configuration.file.YamlConfiguration;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ 
/*    */ public class Utils {
/*    */   private Engine plugin;
/*    */   
/*    */   public Utils(Engine plugin) {
/* 24 */     this.plugin = plugin;
/*    */   }
/*    */   
/*    */   public static String format(String[] text, int to, int from) {
/* 28 */     return StringUtils.join((Object[])text, ' ', to, from).replace("'", "");
/*    */   }
/*    */   
/*    */   public static String deformat(String input) {
/* 32 */     return input.replace("§", "&");
/*    */   }
/*    */   
/*    */   public static String format(String input) {
/* 36 */     return format(input, false);
/*    */   }
/*    */   
/*    */   public static String format(String input, boolean limitChars) {
/* 40 */     String colored = ChatColor.translateAlternateColorCodes('&', input);
/* 41 */     return (limitChars && colored.length() > 16) ? colored.substring(0, 16) : colored;
/*    */   }
/*    */   
/*    */   public static List<Player> getOnline() {
/* 45 */     List<Player> list = new ArrayList<>();
/*    */     
/* 47 */     for (World world : Bukkit.getWorlds()) {
/* 48 */       list.addAll(world.getPlayers());
/*    */     }
/*    */     
/* 51 */     return Collections.unmodifiableList(list);
/*    */   }
/*    */   
/*    */   public static YamlConfiguration getConfig(File file) {
/*    */     try {
/* 56 */       if (!file.exists()) {
/* 57 */         file.createNewFile();
/*    */       }
/* 59 */     } catch (IOException e) {
/* 60 */       if (Engine.utils.sendDebug()) {
/* 61 */         e.printStackTrace();
/*    */       }
/*    */     } 
/*    */     
/* 65 */     return YamlConfiguration.loadConfiguration(file);
/*    */   }
/*    */   public boolean sendDebug() {
/* 68 */     if (this.plugin.getConfig().contains("debug")) {
/* 69 */       return this.plugin.getConfig().getBoolean("debug");
/*    */     }
/* 71 */     return false;
/*    */   }
/*    */   public static YamlConfiguration getConfig(File file, String resource, Plugin plugin) {
/*    */     try {
/* 75 */       if (!file.exists()) {
/* 76 */         file.createNewFile();
/* 77 */         InputStream inputStream = plugin.getResource(resource);
/* 78 */         OutputStream outputStream = new FileOutputStream(file);
/* 79 */         byte[] buffer = new byte[1024];
/*    */         int bytesRead;
/* 81 */         while ((bytesRead = inputStream.read(buffer)) != -1) {
/* 82 */           outputStream.write(buffer, 0, bytesRead);
/*    */         }
/* 84 */         inputStream.close();
/* 85 */         outputStream.flush();
/* 86 */         outputStream.close();
/*    */       } 
/* 88 */     } catch (IOException e) {
/* 89 */       if (Engine.utils.sendDebug()) {
/* 90 */         e.printStackTrace();
/*    */       }
/*    */     } 
/*    */     
/* 94 */     return YamlConfiguration.loadConfiguration(file);
/*    */   }
/*    */ }


/* Location:              C:\Users\Anwender\Downloads\RPEngine-4.6_1.13.jar!\com\Alvaeron\nametags\Utils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */