/*     */ package com.Alvaeron.nametags;
/*     */ 
/*     */ import com.Alvaeron.Engine;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collection;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.entity.Player;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PacketAccessor
/*     */ {
/*     */   static Field MEMBERS;
/*     */   static Field PREFIX;
/*     */   static Field SUFFIX;
/*     */   static Field TEAM_NAME;
/*     */   static Field PARAM_INT;
/*     */   static Field PACK_OPTION;
/*     */   static Field DISPLAY_NAME;
/*     */   static Field PUSH;
/*     */   static Field VISIBILITY;
/*     */   private static Method getHandle;
/*     */   private static Method sendPacket;
/*     */   private static Field playerConnection;
/*     */   private static Class<?> packetClass;
/*     */   
/*     */   static {
/*     */     try {
/*  33 */       String version = Bukkit.getServer().getClass().getPackage().getName().split("\\.")[3];
/*  34 */       Class<?> typeCraftPlayer = Class.forName("org.bukkit.craftbukkit." + version + ".entity.CraftPlayer");
/*  35 */       getHandle = typeCraftPlayer.getMethod("getHandle", new Class[0]);
/*  36 */       packetClass = Class.forName("net.minecraft.server." + version + ".PacketPlayOutScoreboardTeam");
/*  37 */       Class<?> typeNMSPlayer = Class.forName("net.minecraft.server." + version + ".EntityPlayer");
/*  38 */       Class<?> typePlayerConnection = Class.forName("net.minecraft.server." + version + ".PlayerConnection");
/*  39 */       playerConnection = typeNMSPlayer.getField("playerConnection");
/*  40 */       sendPacket = typePlayerConnection.getMethod("sendPacket", new Class[] { Class.forName("net.minecraft.server." + version + ".Packet") });
/*  41 */       PacketData currentVersion = null;
/*  42 */       for (PacketData packetData : PacketData.values()) {
/*  43 */         if (version.contains(packetData.name())) {
/*  44 */           currentVersion = packetData;
/*     */         }
/*     */       } 
/*     */       
/*  48 */       if (currentVersion != null) {
/*  49 */         PREFIX = getNMS(currentVersion.getPrefix());
/*  50 */         SUFFIX = getNMS(currentVersion.getSuffix());
/*  51 */         MEMBERS = getNMS(currentVersion.getMembers());
/*  52 */         TEAM_NAME = getNMS(currentVersion.getTeamName());
/*  53 */         PARAM_INT = getNMS(currentVersion.getParamInt());
/*  54 */         PACK_OPTION = getNMS(currentVersion.getPackOption());
/*  55 */         DISPLAY_NAME = getNMS(currentVersion.getDisplayName());
/*     */         
/*  57 */         if (isPushVersion(version)) {
/*  58 */           PUSH = getNMS(currentVersion.getPush());
/*     */         }
/*     */         
/*  61 */         if (isVisibilityVersion(version)) {
/*  62 */           VISIBILITY = getNMS(currentVersion.getVisibility());
/*     */         }
/*     */       } 
/*  65 */     } catch (Exception e) {
/*  66 */       if (Engine.utils.sendDebug()) {
/*  67 */         e.printStackTrace();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private static boolean isPushVersion(String version) {
/*  73 */     return (Integer.parseInt(version.split("_")[1]) >= 9);
/*     */   }
/*     */   
/*     */   private static boolean isVisibilityVersion(String version) {
/*  77 */     return (Integer.parseInt(version.split("_")[1]) >= 8);
/*     */   }
/*     */   
/*     */   private static Field getNMS(String path) throws Exception {
/*  81 */     Field field = packetClass.getDeclaredField(path);
/*  82 */     field.setAccessible(true);
/*  83 */     return field;
/*     */   }
/*     */   
/*     */   static Object createPacket() {
/*     */     try {
/*  88 */       return packetClass.newInstance();
/*  89 */     } catch (Exception e) {
/*  90 */       if (Engine.utils.sendDebug()) {
/*  91 */         e.printStackTrace();
/*     */       }
/*  93 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   static void sendPacket(Collection<? extends Player> players, Object packet) {
/*  98 */     for (Player player : players) {
/*  99 */       sendPacket(player, packet);
/*     */     }
/*     */   }
/*     */   
/*     */   static void sendPacket(Player player, Object packet) {
/*     */     try {
/* 105 */       Object nmsPlayer = getHandle.invoke(player, new Object[0]);
/* 106 */       Object connection = playerConnection.get(nmsPlayer);
/* 107 */       sendPacket.invoke(connection, new Object[] { packet });
/* 108 */     } catch (Exception e) {
/* 109 */       if (Engine.utils.sendDebug())
/* 110 */         e.printStackTrace(); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Anwender\Downloads\RPEngine-4.6_1.13.jar!\com\Alvaeron\nametags\PacketAccessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */