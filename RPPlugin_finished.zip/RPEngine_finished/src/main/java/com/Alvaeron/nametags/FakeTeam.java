package com.Alvaeron.nametags;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class FakeTeam {

    private static final String UNIQUE_ID =
            UUID.randomUUID().toString()
                    .replaceAll("[^a-zA-Z]", "")
                    .toUpperCase()
                    .substring(0, 5);

    private static int ID = 0;

    private final List<String> members = new ArrayList<>();

    private String name;
    private String prefix = "";
    private String suffix = "";

    public FakeTeam(String prefix, String suffix, int sortPriority, boolean playerTag) {

        this.name = UNIQUE_ID + "_" + getNameFromInput(sortPriority) + ++ID + (playerTag ? "+P" : "");

        if (this.name.length() > 16) {
            this.name = this.name.substring(0, 16);
        }

        this.prefix = prefix;
        this.suffix = suffix;
    }

    public void addMember(String player) {
        if (!members.contains(player)) {
            members.add(player);
        }
    }

    public boolean isSimilar(String prefix, String suffix) {
        return this.prefix.equals(prefix) && this.suffix.equals(suffix);
    }

    public List<String> getMembers() {
        return members;
    }

    public String getName() {
        return name;
    }

    public String getPrefix() {
        return prefix;
    }

    public String getSuffix() {
        return suffix;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }

    public void setSuffix(String suffix) {
        this.suffix = suffix;
    }

    private String getNameFromInput(int input) {
        if (input < 0) return "Z";

        char letter = (char) (input / 5 + 65);
        int repeat = input % 5 + 1;

        StringBuilder builder = new StringBuilder();

        for (int i = 0; i < repeat; i++) {
            builder.append(letter);
        }

        return builder.toString();
    }
}