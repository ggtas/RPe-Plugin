/*     */ package com.Alvaeron.nametags;
/*     */ import com.Alvaeron.Engine;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.OfflinePlayer;
/*     */ import org.bukkit.entity.Player;
/*     */ 
/*     */ public class NametagManager {
/*     */   public NametagManager(Engine plugin) {
/*  14 */     this.TEAMS = new HashMap<>();
/*  15 */     this.CACHED_FAKE_TEAMS = new HashMap<>();
/*     */     this.plugin = plugin;
/*     */   }
/*     */   
/*     */   private final HashMap<String, FakeTeam> TEAMS;
/*     */   private final HashMap<String, FakeTeam> CACHED_FAKE_TEAMS;
/*     */   private Engine plugin;
/*     */   
/*     */   private FakeTeam getFakeTeam(String prefix, String suffix) {
/*  24 */     for (FakeTeam fakeTeam : this.TEAMS.values()) {
/*  25 */       if (fakeTeam.isSimilar(prefix, suffix)) {
/*  26 */         return fakeTeam;
/*     */       }
/*     */     } 
/*     */     
/*  30 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addPlayerToTeam(String player, String prefix, String suffix, int sortPriority, boolean playerTag) {
/*  39 */     FakeTeam previous = getFakeTeam(player);
/*     */     
/*  41 */     if (previous != null && previous.isSimilar(prefix, suffix)) {
/*  42 */       this.plugin.debug(player + " already belongs to a similar team (" + previous.getName() + ")");
/*     */       
/*     */       return;
/*     */     } 
/*  46 */     reset(player);
/*     */     
/*  48 */     FakeTeam joining = getFakeTeam(prefix, suffix);
/*  49 */     if (joining != null) {
/*  50 */       joining.addMember(player);
/*  51 */       this.plugin.debug("Using existing team for " + player);
/*     */     } else {
/*  53 */       joining = new FakeTeam(prefix, suffix, sortPriority, playerTag);
/*  54 */       joining.addMember(player);
/*  55 */       this.TEAMS.put(joining.getName(), joining);
/*  56 */       addTeamPackets(joining);
/*  57 */       this.plugin.debug("Created FakeTeam " + joining.getName() + ". Size: " + this.TEAMS.size());
/*     */     } 
/*     */     
/*  60 */     Player adding = Bukkit.getPlayerExact(player);
/*  61 */     if (adding != null) {
/*  62 */       addPlayerToTeamPackets(joining, adding.getName());
/*  63 */       cache(adding.getName(), joining);
/*     */     } else {
/*  65 */       OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer(player);
/*  66 */       addPlayerToTeamPackets(joining, offlinePlayer.getName());
/*  67 */       cache(offlinePlayer.getName(), joining);
/*     */     } 
/*     */     
/*  70 */     this.plugin.debug(player + " has been added to team " + joining.getName());
/*     */   }
/*     */   
/*     */   public FakeTeam reset(String player) {
/*  74 */     return reset(player, decache(player));
/*     */   }
/*     */ 
/*     */   
/*     */   private FakeTeam reset(String player, FakeTeam fakeTeam) {
/*  79 */     if (fakeTeam != null && fakeTeam.getMembers().remove(player)) {
/*     */       boolean delete;
/*  81 */       Player removing = Bukkit.getPlayerExact(player);
/*  82 */       if (removing != null) {
/*  83 */         delete = removePlayerFromTeamPackets(fakeTeam, new String[] { removing.getName() });
/*     */       } else {
/*  85 */         OfflinePlayer toRemoveOffline = Bukkit.getOfflinePlayer(player);
/*  86 */         delete = removePlayerFromTeamPackets(fakeTeam, new String[] { toRemoveOffline.getName() });
/*     */       } 
/*     */       
/*  89 */       this.plugin.debug(player + " was removed from " + fakeTeam.getName());
/*  90 */       if (delete) {
/*  91 */         removeTeamPackets(fakeTeam);
/*  92 */         this.TEAMS.remove(fakeTeam.getName());
/*  93 */         this.plugin.debug("FakeTeam " + fakeTeam.getName() + " has been deleted. Size: " + this.TEAMS.size());
/*     */       } 
/*     */     } 
/*     */     
/*  97 */     return fakeTeam;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private FakeTeam decache(String player) {
/* 104 */     return this.CACHED_FAKE_TEAMS.remove(player);
/*     */   }
/*     */   
/*     */   public FakeTeam getFakeTeam(String player) {
/* 108 */     return this.CACHED_FAKE_TEAMS.get(player);
/*     */   }
/*     */   
/*     */   private void cache(String player, FakeTeam fakeTeam) {
/* 112 */     this.CACHED_FAKE_TEAMS.put(player, fakeTeam);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNametag(String player, String prefix, String suffix) {
/* 119 */     setNametag(player, prefix, suffix, -1);
/*     */   }
/*     */   
/*     */   void setNametag(String player, String prefix, String suffix, int sortPriority) {
/* 123 */     setNametag(player, prefix, suffix, sortPriority, false);
/*     */   }
/*     */   
/*     */   void setNametag(String player, String prefix, String suffix, int sortPriority, boolean playerTag) {
/* 127 */     addPlayerToTeam(player, (prefix != null) ? prefix : "", (suffix != null) ? suffix : "", sortPriority, playerTag);
/*     */   }
/*     */   
/*     */   public void sendTeams(Player player) {
/* 131 */     for (FakeTeam fakeTeam : this.TEAMS.values()) {
/* 132 */       (new PacketWrapper(fakeTeam.getName(), fakeTeam.getPrefix(), fakeTeam.getSuffix(), 0, fakeTeam.getMembers())).send(player);
/*     */     }
/*     */   }
/*     */   
/*     */   void reset() {
/* 137 */     for (FakeTeam fakeTeam : this.TEAMS.values()) {
/* 138 */       removePlayerFromTeamPackets(fakeTeam, fakeTeam.getMembers());
/* 139 */       removeTeamPackets(fakeTeam);
/*     */     } 
/* 141 */     this.CACHED_FAKE_TEAMS.clear();
/* 142 */     this.TEAMS.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void removeTeamPackets(FakeTeam fakeTeam) {
/* 149 */     (new PacketWrapper(fakeTeam.getName(), fakeTeam.getPrefix(), fakeTeam.getSuffix(), 1, new ArrayList())).send();
/*     */   }
/*     */   
/*     */   private boolean removePlayerFromTeamPackets(FakeTeam fakeTeam, String... players) {
/* 153 */     return removePlayerFromTeamPackets(fakeTeam, Arrays.asList(players));
/*     */   }
/*     */   
/*     */   private boolean removePlayerFromTeamPackets(FakeTeam fakeTeam, List<String> players) {
/* 157 */     (new PacketWrapper(fakeTeam.getName(), 4, players)).send();
/* 158 */     fakeTeam.getMembers().removeAll(players);
/* 159 */     return fakeTeam.getMembers().isEmpty();
/*     */   }
/*     */   
/*     */   private void addTeamPackets(FakeTeam fakeTeam) {
/* 163 */     (new PacketWrapper(fakeTeam.getName(), fakeTeam.getPrefix(), fakeTeam.getSuffix(), 0, fakeTeam.getMembers())).send();
/*     */   }
/*     */   
/*     */   private void addPlayerToTeamPackets(FakeTeam fakeTeam, String player) {
/* 167 */     (new PacketWrapper(fakeTeam.getName(), 3, Collections.singletonList(player))).send();
/*     */   }
/*     */ }


/* Location:              C:\Users\Anwender\Downloads\RPEngine-4.6_1.13.jar!\com\Alvaeron\nametags\NametagManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */