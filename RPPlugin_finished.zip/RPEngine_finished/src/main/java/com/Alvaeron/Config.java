package com.Alvaeron;

public class Config {

    public static double getDouble(String path, double def) {
        // TODO hook into plugin config system
        return def;
    }
}