package com.Alvaeron.utils;

public class TextTransformUtil {

    public static String heavy(String input) {
        return "§k" + input; // Minecraft Obfuscation Effekt
    }

    public static String scramble(String input) {
        return input.replaceAll(".", "*");
    }
    public static String partial(String input) {
        int half = input.length() / 2;
        return "§k" + input.substring(0, half) + "§r" + input.substring(half);
    }
}