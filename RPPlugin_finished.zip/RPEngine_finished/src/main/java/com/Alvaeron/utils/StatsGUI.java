package com.Alvaeron.utils;

import com.Alvaeron.Engine;
import com.Alvaeron.player.RoleplayPlayer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Arrays;

public class StatsGUI {

    public Inventory build(RoleplayPlayer rpp) {

        Inventory inv = Bukkit.createInventory(new StatsHolder(), 54, "Stats");

        int slot = 10;

        for (String statName : Engine.getInstance().getConfig().getStringList("CardStats")) {

            if (slot > 44) break; // Schutz gegen Overflow

            int value = rpp.getStat(statName);

            inv.setItem(slot, statItem(statName, value));

            slot++;
        }

        inv.setItem(49, switchButton());

        return inv;
    }

    private ItemStack statItem(String statName, int value) {

        ItemStack item = new ItemStack(Material.PAPER);
        ItemMeta meta = item.getItemMeta();

        meta.setDisplayName("§b" + statName);
        meta.setLore(Arrays.asList(
                "§7Value:",
                "§f" + value,
                "",
                "§aLEFT CLICK = Increase",
                "§cRIGHT CLICK = Decrease"
        ));

        item.setItemMeta(meta);
        return item;
    }

    private ItemStack switchButton() {

        ItemStack item = new ItemStack(Material.NAME_TAG);
        ItemMeta meta = item.getItemMeta();

        meta.setDisplayName("§aCharacter");

        item.setItemMeta(meta);
        return item;
    }
}