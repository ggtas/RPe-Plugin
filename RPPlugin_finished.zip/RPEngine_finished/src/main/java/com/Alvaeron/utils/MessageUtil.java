/*     */ package com.Alvaeron.utils;
/*     */ 
/*     */ import com.Alvaeron.Engine;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.entity.Player;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MessageUtil
/*     */ {
/*     */   private Engine plugin;
/*     */   
/*     */   public MessageUtil(Engine plugin) {
/*  17 */     this.plugin = plugin;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void sendRangedMessage(Player player, String text, String key) {
/*  31 */     for (Player p : Bukkit.getOnlinePlayers()) {
/*  32 */       if (player.getWorld() == p.getWorld() && 
/*  33 */         p.getLocation().distance(player.getLocation()) <= this.plugin.getConfig().getInt(key)) {
/*  34 */         p.sendMessage(text);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void sendLocalizedMessage(Player player, String key) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String containsCaseInsensitive(String s, Set<String> l) {
/*  54 */     for (String string : l) {
/*  55 */       if (string.equalsIgnoreCase(s)) {
/*  56 */         return string;
/*     */       }
/*     */     } 
/*  59 */     return null;
/*     */   }
/*     */   public String containsCaseInsensitive(String s, List<String> l) {
/*  62 */     for (String string : l) {
/*  63 */       if (string.equalsIgnoreCase(s)) {
/*  64 */         return string;
/*     */       }
/*     */     } 
/*  67 */     return null;
/*     */   }
/*     */   public String getValueFromSet(String s, Set<String> l) {
/*  70 */     for (String string : l) {
/*  71 */       if (string.equalsIgnoreCase(s)) {
/*  72 */         return string;
/*     */       }
/*     */     } 
/*  75 */     return null;
/*     */   }
/*     */   public String getValueFromSet(String s, List<String> l) {
/*  78 */     for (String string : l) {
/*  79 */       if (string.equalsIgnoreCase(s)) {
/*  80 */         return string;
/*     */       }
/*     */     } 
/*  83 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChatColor getRaceColour(String race) {
/*  91 */     if (!this.plugin.getConfig().contains("Races." + race + ".Color")) {
/*  92 */       return ChatColor.GRAY;
/*     */     }
/*  94 */     String color = this.plugin.getConfig().getString("Races." + race + ".Color");
/*     */     try {
/*  96 */       return ChatColor.valueOf(color);
/*  97 */     } catch (IllegalArgumentException ex) {
/*  98 */       return ChatColor.WHITE;
/*     */     } 
/*     */   }
/*     */   
/*     */   public ChatColor getLangColour(String language) {
/*     */     boolean hasColorConfig;
/*     */     try {
/* 105 */       hasColorConfig = this.plugin.getConfig().getConfigurationSection("Languages." + language).getKeys(false).contains("Color");
/* 106 */     } catch (NullPointerException ex) {
/* 107 */       hasColorConfig = false;
/*     */     } 
/* 109 */     if (language.equalsIgnoreCase("Common") || !hasColorConfig)
/* 110 */       return ChatColor.GRAY; 
/* 111 */     String color = this.plugin.getConfig().getString("Languages." + language + ".Color");
/*     */     try {
/* 113 */       return ChatColor.valueOf(color);
/* 114 */     } catch (IllegalArgumentException ex) {
/* 115 */       return ChatColor.WHITE;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String replaceIfOdd(String stringToChange, String searchingWord, String replacingWord) {
/* 121 */     String separator = "#######";
/* 122 */     String splittingString = stringToChange.replaceAll(searchingWord, "#######" + searchingWord);
/*     */     
/* 124 */     String[] splitArray = splittingString.split("#######");
/* 125 */     String result = "";
/* 126 */     for (int i = 0; i < splitArray.length; i++) {
/* 127 */       if (i % 2 == 1) {
/* 128 */         splitArray[i] = splitArray[i].replace(searchingWord, replacingWord);
/*     */       }
/* 130 */       result = result + splitArray[i];
/*     */     } 
/* 132 */     return result;
/*     */   }
/*     */   
/*     */   public String replaceIfEven(String stringToChange, String searchingWord, String replacingWord) {
/* 136 */     String separator = "#######";
/* 137 */     String splittingString = stringToChange.replaceAll(searchingWord, "#######" + searchingWord);
/*     */     
/* 139 */     String[] splitArray = splittingString.split("#######");
/* 140 */     String result = "";
/* 141 */     for (int i = 0; i < splitArray.length; i++) {
/* 142 */       if (i % 2 == 0) {
/* 143 */         splitArray[i] = splitArray[i].replace(searchingWord, replacingWord);
/*     */       }
/* 145 */       result = result + splitArray[i];
/*     */     } 
/* 147 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\Anwender\Downloads\RPEngine-4.6_1.13.jar!\com\Alvaero\\utils\MessageUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */