
package com.Alvaeron.utils;

import com.Alvaeron.Engine;
import com.Alvaeron.player.RoleplayPlayer;
import org.bukkit.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.*;
import java.util.*;

public class CardStatsGUI {

    private final Engine plugin;

    public CardStatsGUI(Engine plugin) {
        this.plugin = plugin;
    }

    public Inventory build(RoleplayPlayer rpp) {

        Inventory inv = Bukkit.createInventory(null, 27, ChatColor.DARK_GREEN + "Character Stats");

        int slot = 10;

        for (String stat : plugin.getConfig().getStringList("CardStats")) {

            ItemStack item = new ItemStack(Material.PAPER);
            ItemMeta meta = item.getItemMeta();

            meta.setDisplayName(ChatColor.GREEN + stat);
            meta.setLore(Arrays.asList(
                    ChatColor.GRAY + "Value: " + ChatColor.WHITE + rpp.getStat(stat)
            ));
            item.setItemMeta(meta);

            inv.setItem(slot, item);
            slot++;
        }

        return inv;
    }
}
