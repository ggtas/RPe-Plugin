package com.Alvaeron.utils;

import com.Alvaeron.Engine;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class SelectionGUI {

    private final Engine plugin;

    public SelectionGUI(Engine plugin) {
        this.plugin = plugin;
    }

    public Inventory buildRaceGUI() {

        Inventory inv = Bukkit.createInventory(new SelectionHolder(), 54, "Select Race");

        if (plugin.getConfig().getConfigurationSection("Races") == null)
            return inv;

        int slot = 0;

        for (String race : plugin.getConfig()
                .getConfigurationSection("Races")
                .getKeys(false)) {

            ItemStack item = new ItemStack(Material.BOOK);
            ItemMeta meta = item.getItemMeta();

            meta.setDisplayName(ChatColor.GREEN + race);
            item.setItemMeta(meta);

            inv.setItem(slot++, item);
        }

        return inv;
    }

    public Inventory buildNationGUI() {

        Inventory inv = Bukkit.createInventory(new SelectionHolder(), 54, "Select Nation");

        if (plugin.getConfig().getConfigurationSection("Nations") == null)
            return inv;

        int slot = 0;

        for (String nation : plugin.getConfig()
                .getConfigurationSection("Nations")
                .getKeys(false)) {

            ItemStack item = new ItemStack(Material.MAP);
            ItemMeta meta = item.getItemMeta();

            meta.setDisplayName(ChatColor.AQUA + nation);
            item.setItemMeta(meta);

            inv.setItem(slot++, item);
        }

        return inv;
    }
}