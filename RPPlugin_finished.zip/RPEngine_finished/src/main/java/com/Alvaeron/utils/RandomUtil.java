package com.Alvaeron.utils;

import java.util.concurrent.ThreadLocalRandom;

public class RandomUtil {

    public static double between(double min, double max) {
        return ThreadLocalRandom.current().nextDouble(min, max);
    }
}