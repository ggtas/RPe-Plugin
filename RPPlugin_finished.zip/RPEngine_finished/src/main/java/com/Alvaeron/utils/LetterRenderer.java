/*    */ package com.Alvaeron.utils;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.regex.Matcher;
/*    */ import java.util.regex.Pattern;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.map.MapCanvas;
/*    */ import org.bukkit.map.MapFont;
/*    */ import org.bukkit.map.MapRenderer;
/*    */ import org.bukkit.map.MapView;
/*    */ import org.bukkit.map.MinecraftFont;
/*    */ 
/*    */ public class LetterRenderer extends MapRenderer {
/*    */   private boolean drawn = false;
/*    */   private String text;
/*    */   
/*    */   public LetterRenderer(String text) {
/* 19 */     this.text = text;
/*    */   }
/*    */ 
/*    */   
/*    */   public void render(MapView mapView, MapCanvas mapCanvas, Player player) {
/* 24 */     if (!this.drawn) {
/* 25 */       List<String> lines = splitString(this.text, 24);
/* 26 */       for (int i = 0; i < lines.size(); i++)
/* 27 */         mapCanvas.drawText(5, 10 * i + 5, (MapFont)MinecraftFont.Font, lines.get(i)); 
/* 28 */       this.drawn = true;
/*    */     } 
/*    */   }
/*    */   
/*    */   private static List<String> splitString(String message, int lineSize) {
/* 33 */     List<String> lines = new ArrayList<>();
/* 34 */     Pattern pattern = Pattern.compile("\\b.{1," + (lineSize - 1) + "}\\b\\W?");
/* 35 */     Matcher matcher = pattern.matcher(message);
/* 36 */     while (matcher.find()) {
/* 37 */       lines.add(matcher.group());
/*    */     }
/* 39 */     return lines;
/*    */   }
/*    */ }


/* Location:              C:\Users\Anwender\Downloads\RPEngine-4.6_1.13.jar!\com\Alvaero\\utils\LetterRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */