package com.Alvaeron.utils;

import com.Alvaeron.Engine;
import com.Alvaeron.player.RoleplayPlayer;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class CharackterCardGUI {

    private final Engine plugin;

    public CharackterCardGUI(Engine plugin) {
        this.plugin = plugin;
    }

    public Inventory build(RoleplayPlayer rpp) {
        return buildCharacter(rpp);
    }

    public Inventory buildCharacter(RoleplayPlayer rpp) {

        CharacterHolder holder = new CharacterHolder();
        Inventory inv = Bukkit.createInventory(holder, 54, "Character");
        holder.setInventory(inv);

        inv.setItem(10, createItem(Material.NAME_TAG, "Name", rpp.getName()));
        inv.setItem(11, createItem(Material.CLOCK, "Age", String.valueOf(rpp.getAge())));
        inv.setItem(12, createItem(Material.WRITABLE_BOOK, "Description", rpp.getDesc()));

        inv.setItem(13, createItem(Material.NAME_TAG, "Race", rpp.getRace()));
        inv.setItem(14, createItem(Material.MAP, "Nation", rpp.getNation()));
        inv.setItem(15, createGenderItem(rpp));

        inv.setItem(49, createButton(Material.PAPER, ChatColor.GREEN + "Stats"));

        return inv;
    }

    public Inventory buildStats(RoleplayPlayer rpp) {

        Inventory inv = Bukkit.createInventory(new CardHolder(), 54, "Stats");

        int slot = 10;

        for (String stat : plugin.getConfig().getStringList("CardStats")) {
            inv.setItem(slot++, createStatItem(stat, rpp.getStat(stat)));
        }

        inv.setItem(49, createButton(Material.ARROW, ChatColor.RED + "Back"));

        return inv;
    }

    /* --------------------------------------------------------- */
    /* ITEM BUILDERS                                             */
    /* --------------------------------------------------------- */

    private ItemStack createItem(Material mat, String name, String value) {

        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();

        meta.setDisplayName(ChatColor.GREEN + name);
        meta.setLore(java.util.Arrays.asList(
                ChatColor.GRAY + "Value:",
                ChatColor.WHITE + value,
                "",
                ChatColor.YELLOW + "Click to edit"
        ));

        item.setItemMeta(meta);
        return item;
    }

    private ItemStack createStatItem(String stat, int value) {

        ItemStack item = new ItemStack(Material.PAPER);
        ItemMeta meta = item.getItemMeta();

        meta.setDisplayName(ChatColor.AQUA + stat);
        meta.setLore(java.util.Arrays.asList(
                ChatColor.GRAY + "Value:",
                ChatColor.WHITE + String.valueOf(value),
                "",
                ChatColor.YELLOW + "Left Click = +1",
                ChatColor.YELLOW + "Right Click = -1"
        ));

        item.setItemMeta(meta);
        return item;
    }

    private ItemStack createButton(Material mat, String name) {

        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();

        meta.setDisplayName(name);

        item.setItemMeta(meta);
        return item;
    }
    private ItemStack createGenderItem(RoleplayPlayer rpp) {

        ItemStack item = new ItemStack(Material.PLAYER_HEAD);
        ItemMeta meta = item.getItemMeta();

        meta.setDisplayName(ChatColor.GREEN + "Gender");
        meta.setLore(java.util.Arrays.asList(
                ChatColor.GRAY + "Value:",
                ChatColor.WHITE + rpp.getGender().getName(),
                "",
                ChatColor.YELLOW + "Left Click = Next",
                ChatColor.YELLOW + "Right Click = Previous"
        ));

        item.setItemMeta(meta);
        return item;
    }
}