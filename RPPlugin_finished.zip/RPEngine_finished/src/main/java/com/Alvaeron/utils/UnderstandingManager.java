package com.Alvaeron.utils;

import com.Alvaeron.Engine;
import com.Alvaeron.MySQLManager;

import java.util.*;
import java.sql.*;
import java.util.UUID;

public class UnderstandingManager {

    private final Map<UUID, Map<String, Double>> cache = new HashMap<>();
    private final MySQLManager mysql;

    public UnderstandingManager(MySQLManager mysql) {
        this.mysql = mysql;
    }

    public double getUnderstanding(UUID uuid, String language) {
        Map<String, Double> map = cache.computeIfAbsent(uuid, k -> load(uuid));
        return map.getOrDefault(language, getDefaultUnderstanding(language));
    }

    public void addUnderstanding(UUID uuid, String language, double amount) {

        Map<String, Double> map = cache.computeIfAbsent(uuid, k -> load(uuid));

        double current = map.getOrDefault(language, getDefaultUnderstanding(language));
        double max = getMaxUnderstanding(language);

        double updated = Math.min(current + amount, max);

        map.put(language, updated);
        save(uuid, language, updated);
    }

    private Map<String, Double> load(UUID uuid) {

        Map<String, Double> map = new HashMap<>();

        try {
            PreparedStatement ps = Engine.mm.getConnection().prepareStatement(
                    "SELECT language, understanding FROM rp_language_understanding WHERE player_uuid=?"
            );

            ps.setString(1, uuid.toString());
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                map.put(rs.getString("language"), rs.getDouble("understanding"));
            }

            rs.close();
            ps.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return map;
    }

    private void save(UUID uuid, String language, double value) {

        try {
            PreparedStatement ps = Engine.mm.getConnection().prepareStatement(
                    "REPLACE INTO rp_language_understanding (player_uuid, language, understanding) VALUES (?, ?, ?)"
            );

            ps.setString(1, uuid.toString());
            ps.setString(2, language);
            ps.setDouble(3, value);

            ps.executeUpdate();
            ps.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private double getDefaultUnderstanding(String language) {
        return Engine.getInstance().getConfig().getDouble(
                "Languages." + language + ".default-understanding", 0.0
        );
    }

    private double getMaxUnderstanding(String language) {
        return Engine.getInstance().getConfig().getDouble(
                "Languages." + language + ".max-understanding", 100.0
        );
    }

    public void saveCache(UUID uuid) {

        Map<String, Double> map = cache.get(uuid);

        if (map == null) return;

        for (Map.Entry<String, Double> entry : map.entrySet()) {
            save(uuid, entry.getKey(), entry.getValue());
        }
    }

    public void clearCache(UUID uuid) {
        cache.remove(uuid);
    }

    public Map<String, Double> getLanguages(UUID uuid) {

        Map<String, Double> result = new HashMap<>();

        try (PreparedStatement ps = Engine.mm.getConnection().prepareStatement(
                "SELECT language, understanding FROM rp_language_understanding WHERE player_uuid = ?")) {

            ps.setString(1, uuid.toString());

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String language = rs.getString("language");
                double understanding = rs.getDouble("understanding");

                result.put(language, understanding);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return result;
    }

}
