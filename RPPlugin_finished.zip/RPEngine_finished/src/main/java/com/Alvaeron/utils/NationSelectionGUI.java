package com.Alvaeron.utils;

import com.Alvaeron.Engine;
import org.bukkit.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;

public class NationSelectionGUI {

    public static Inventory build() {

        SelectionHolder holder = new SelectionHolder();
        Inventory inv = Bukkit.createInventory(holder, 54, "Select Nation");
        holder.setInventory(inv);

        if (Engine.getInstance().getConfig().getConfigurationSection("Nations") == null)
            return inv;

        int slot = 10;

        for (String nation : Engine.getInstance().getConfig()
                .getConfigurationSection("Nations")
                .getKeys(false)) {

            ItemStack item = new ItemStack(Material.BOOK);
            ItemMeta meta = item.getItemMeta();
            ItemStack back = new ItemStack(Material.ARROW);
            ItemMeta beta = back.getItemMeta();
            beta.setDisplayName("§c⬅ Back");
            back.setItemMeta(beta);

            inv.setItem(49, back);

            meta.setDisplayName(ChatColor.AQUA + nation);

            meta.setLore(java.util.List.of(
                    ChatColor.GRAY + "Click to select"
            ));

            item.setItemMeta(meta);

            inv.setItem(slot++, item);
        }

        return inv;
    }
}