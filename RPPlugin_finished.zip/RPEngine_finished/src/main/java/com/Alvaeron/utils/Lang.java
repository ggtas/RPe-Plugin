package com.Alvaeron.utils;

import com.Alvaeron.Engine;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.YamlConfiguration;

/*     */
/*     */
/*     */ public enum Lang
        /*     */ {
    /*  10 */   TITLE("title-name", "&4[&fRPEngine&4]"),
    /*  11 */   PLAYER_ONLY("player-only", "Sorry but that can only be run by a player!"),
    /*  12 */   NO_PERMS("no-permissions", "&cError: &fYou don't have permission for that!"),
    /*  13 */   MUST_BE_NUMBER("must-be-number", "&cError: &fPlease use a number not a word!."),
    /*  14 */   CHAT_DISABLED("chat-disabled", "&cError: &fChat functionality disabled by admin"),
    /*  15 */   VERSION("version", "&6Currently running version: &f%v"),
    /*  16 */   RELOAD("reload", "&6Plugin reloaded!"),
    /*  17 */   RP_JOIN("rp-join", "&eYou are now chatting in &f: RP"),
    /*     */
    /*  19 */   CARD_OWN("card-own", "&a-=-=-=-=- &bYour Card &a-=-=-=-=-"),
    /*  20 */   CARD_OTHERS("card-others", "&a-=-=-=-=-&b %p's card &a-=-=-=-=-"),
    /*  21 */   CARD_CLICK_TO_EDIT("card-click-to-edit", "Click to edit"),
    /*  22 */   CARD_CLICK_TO_EDIT_FIELDS("card-click-to-edit-fields", "&bClick the fields to edit them"),
    /*  23 */   CARD_CLICK_TO_GENDER("card-click-to-gender", "Click to set your gender to %g"),
    /*  24 */   CARD_CLICK_TO_RACE("card-click-to-race", "Click to set your race to %r"),
    /*  25 */   CARD_CLICK_TO_NATION("card-click-to-nation", "Click to set your nation to %n"),
    /*  26 */   CARD_SELECT_GENDER("card-select-gender", "&aSelect your Gender"),
    /*  27 */   CARD_SELECT_RACE("card-select-race", "&aSelect your Race"),
    /*  28 */   CARD_SELECT_NATION("card-select-nation", "&aSelect your Nations"),
    /*  29 */   CARD_UPDATED_TO("card-updated-to", "&a%f updated to&f: %v"),
    /*  30 */   CARD_CLICK_TO_SHOW("card-click-to-show", "Click to show your card"),
    /*     */
    /*  32 */   CARD_FIELD_NAME("card-field-name", "Name"),
    /*  33 */   CARD_FIELD_AGE("card-field-age", "Age"),
    /*  34 */   CARD_FIELD_GENDER("card-field-gender", "Gender"),
    /*  35 */   CARD_FIELD_GENDER_MALE("card-field-gender-male", "Male"),
    /*  36 */   CARD_FIELD_GENDER_FEMALE("card-field-gender-female", "Female"),
    /*  37 */   CARD_FIELD_GENDER_NONE("card-field-gender-none", "None"),
    /*  38 */   CARD_FIELD_RACE("card-field-race", "Race"),
    /*  39 */   CARD_FIELD_NATION("card-field-nation", "Nation"),
    /*  40 */   CARD_FIELD_DESC("card-field-desc", "Description"),
    /*  41 */   CARD_FIELD_SKILLS("card-field-skills", "Skills"),
    /*     */
    /*  43 */   BIRD_USAGE("bird-usage", "&cUsage: &f/bird [player] [message]"),
    /*  44 */   BIRD_OFFLINE("bird-offline", "&f%p &cis offline"),
    /*  45 */   BIRD_DIFFERENT_WORLD("bird-different-world", "&eYour bird gets lost in an interdimentional rift &c(Player is in another world)"),
    /*  46 */   BIRD_PAPER("bird-paper", "&cYou need at least one piece of paper to send a bird!"),
    /*  47 */   BIRD_LOST("bird-lost", "&cYour &abird &cgot lost"),
    /*  48 */   BIRD_DELIVER("bird-deliver", "&bYour &abird &bhas delivered your letter to %n &f(%p)."),
    /*  49 */   BIRD_LAND("bird-land", "&bA &abird &blands in front of you with a letter."),
    /*  50 */   BIRD_SENT("bird-sent", "&bYou've sent a &abird to %n &f(%p)."),
    /*  51 */   ROLL_USAGE("roll-usage", "&cUsage: &f/roll AdB[x/]C[+-]D\n&6A - &bthe number of dice to roll\n&6B - &bthe number of sides on each die\n&6C - &ba multiplier or divisor (after x or /)\n&6D - &ba number to add or subtract (after + or -)\n&6(&bExamples: d6, 3d6, 4d6+1, 3d6x10, d6/2&6)"),
    /*  52 */   ROLL_MAX("roll-max", "&cNumber is too high. Please use a number below %n."),
    /*  53 */   ROLL_RESULT("roll-result", "&f[%c] &b%r has rolled &6%n &bout of &6%m."),
    /*  54 */   ROLL_CONSOLE("roll-console", "&7 The Console &bhas rolled &6%n &bout of &6%m."),
    /*     */
    /*  56 */   COUNTDOWN_USAGE("countdown-usage", "&cUsage: &f/countdown [time]."),
    /*  57 */   COUNTDOWN_NEGATIVE("countdown-negative", "&CYou can not use a negative number!"),
    /*  58 */   COUNTDOWN_MAX("countdown-max", "&cYou can not use a number over %m!"),
    /*  59 */   COUNTDOWN_START("countdown-start", "&b%r &f(%p) &bhas started a countdown from &6%n."),
    /*     */
    /*  61 */   SPAWNPOINT_USAGE("spawnpoint-usage", "&cUsage: &f/%c [%l]."),
    /*  62 */   SPAWNPOINT_SET_USAGE("spawnpoint-set-usage", "&cUsage: &f/%c set [%l]."),
    /*  63 */   SPAWNPOINT_SET("spawnpoint-set", "&aSpawnpoint of &f%n &aset to your location."),
    /*  64 */   SPAWNPOINT_NO_NATION("spawnpoint-no-nation", "&cError: &fPlease set your nation with /card nation."),
    /*  65 */   SPAWNPOINT_CONFIG_ERROR("spawnpoint-config-error", "&cError: &fSomething went wrong with retrieving data from the config file."),
    /*  66 */   SPAWNPOINT_TELEPORT("spawnpoint-teleport", "&aYou have been teleported to &f%n."),
    /*     */
    /*  68 */   CHAT_SHOUT_USAGE("chat-shout-usage", "&cUsage: &f/%c [message]."),
    /*  69 */   CHAT_SHOUT_FORMAT("chat-shout-format", "&c[Shout] &7%n: &f%m"),
    /*  70 */   CHAT_WHISPER_USAGE("chat-whisper-usage", "&cUsage: &f/%c [message]."),
    /*  71 */   CHAT_WHISPER_FORMAT("chat-whisper-format", "&9[Whisper] &7%n: &f%m"),
    /*     */
    /*  73 */   CARD_NAME_USAGE("card-name-usage", "&cUsage: &f/card name [name]."),
    /*  74 */   CARD_AGE_RACE_MAX("card-age-race-max", "&cError: &g%r can not be any older than %a"),
    /*  75 */   CARD_AGE_MAX("card-age-max", "&cError: &fYou can no be any older than %a"),
    /*  76 */   CARD_AGE_USAGE("card-age-usage", "&cUsage: &f/card age [age]."),
    /*  77 */   CARD_GENDER_USAGE("card-gender-usage", "&cUsage: &f/card gender [male/female]."),
    /*  78 */   CARD_RACE_USAGE("card-race-usage", "&cUsage: &f/card race %r."),
    /*  79 */   CARD_NATION_USAGE("card-nation-usage", "&cUsage: &f/card nation %n."),
    /*  80 */   CARD_DESC_USAGE("card-desc-usage", "&cUsage: &f/card desc [description]."),
    /*  81 */   CARD_OFFLINE("card-offline", "&cError: &f%p is offline."),
    /*  82 */   CARD_SKILLS_USAGE("card-skills-usage", "&cUsage: &f/card skills add/remove %r."),
    /*     */
    /*  84 */   SOCIALSPY_MSG_FORMAT("socialspy-msg-format", "[%s -> %r] %m");
    /*     */
    /*     */
    /*     */   private String path;
    /*     */
    /*     */
    /*     */   private String def;
    /*     */
    /*     */   private static YamlConfiguration LANG;

    /*     */
    /*     */
    /*     */   Lang(String path, String start) {
        /*  96 */
        this.path = path;
        /*  97 */
        this.def = start;
        /*     */
    }

    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    public static void setFile(YamlConfiguration config) {
        /* 105 */
        LANG = config;
        /*     */
    }

    /*     */
    /*     */
    /*     */
    public String toString() {
        /* 110 */
        if (this == TITLE)
            /* 111 */ return ChatColor.translateAlternateColorCodes('&', LANG.getString(this.path, this.def)) + " ";
        /* 112 */
        return ChatColor.translateAlternateColorCodes('&', LANG.getString(this.path, this.def));
        /*     */
    }

    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    public String getDefault() {
        /* 120 */
        return this.def;
        /*     */
    }

    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    public String getPath() {
        /* 128 */
        return this.path;
        /*     */
    }
    /*     */

    public static void init(Engine plugin) {
        // aktuell leer reicht völlig
    }

}
