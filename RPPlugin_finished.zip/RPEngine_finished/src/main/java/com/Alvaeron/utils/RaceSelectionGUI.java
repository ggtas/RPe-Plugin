package com.Alvaeron.utils;

import com.Alvaeron.Engine;
import org.bukkit.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;

public class RaceSelectionGUI {

    public static Inventory build() {

        SelectionHolder holder = new SelectionHolder();
        Inventory inv = Bukkit.createInventory(holder, 54, "Select Race");
        holder.setInventory(inv);

        if (Engine.getInstance().getConfig().getConfigurationSection("Races") == null)
            return inv;

        int slot = 10;

        for (String race : Engine.getInstance().getConfig()
                .getConfigurationSection("Races")
                .getKeys(false)) {

            ItemStack item = new ItemStack(Material.PAPER);
            ItemMeta meta = item.getItemMeta();

            meta.setDisplayName(ChatColor.GREEN + race);

            meta.setLore(java.util.List.of(
                    ChatColor.GRAY + "Click to select"
            ));

            item.setItemMeta(meta);

            inv.setItem(slot++, item);
        }

        return inv;
    }
}