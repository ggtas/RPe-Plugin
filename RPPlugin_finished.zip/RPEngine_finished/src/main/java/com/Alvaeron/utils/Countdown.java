package com.Alvaeron.utils;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

public class Countdown {

    private final Plugin plugin;
    private BukkitTask task;
    private int time;

    public Countdown(Plugin plugin) {
        this.plugin = plugin;
    }

    public void startCountdown(Player player, boolean global, int seconds) {

        this.time = seconds;

        if (task != null) {
            task.cancel(); // verhindert doppelte Timer
        }

        task = Bukkit.getScheduler().runTaskTimer(plugin, () -> {

            if (time <= 0) {
                cancel();

                if (global) {
                    Bukkit.broadcastMessage(ChatColor.GREEN + "Go!");
                } else if (player != null) {
                    player.sendMessage(ChatColor.GREEN + "Go!");
                }

                return;
            }

            if (global) {
                Bukkit.broadcastMessage(ChatColor.GOLD + String.valueOf(time));
            } else if (player != null) {
                player.sendMessage(ChatColor.GOLD + String.valueOf(time));
            }

            time--;

        }, 0L, 20L); // 20 Ticks = 1 Sekunde
    }

    public void cancel() {
        if (task != null) {
            task.cancel();
            task = null;
        }
    }
}
