package com.Alvaeron.utils;

import com.Alvaeron.Engine;
import com.Alvaeron.player.RoleplayPlayer;

import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.TextComponent;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

import java.util.HashSet;
import java.util.Set;

public class RPLanguage {

    private final Engine plugin;

    public RPLanguage(Engine plugin) {
        this.plugin = plugin;
    }

    public void sendLanguages(RoleplayPlayer rpp) {

        if (rpp == null || rpp.getPlayer() == null)
            return;

        Player player = rpp.getPlayer();

        ConfigurationSection sec = plugin.getConfig().getConfigurationSection("Languages");

        if (sec == null) {
            player.sendMessage("§cNo languages configured.");
            return;
        }

        Set<String> available = new HashSet<>(sec.getKeys(false));

        // Nur Sprachen anzeigen, die Spieler kennt
        available.removeIf(lang -> !rpp.getSkills().contains(lang));

        if (available.isEmpty()) {
            player.sendMessage("§7You don't know any languages.");
            return;
        }

        player.sendMessage("§fSpeak which language?");

        for (String lang : available) {

            TextComponent msg = new TextComponent("§b" + lang);

            msg.setClickEvent(new ClickEvent(
                    ClickEvent.Action.RUN_COMMAND,
                    "/speak " + lang
            ));

            player.sendMessage(msg.getText());
        }
    }

    public Set<String> getAvailableLanguages() {

        ConfigurationSection sec = plugin.getConfig().getConfigurationSection("Languages");

        if (sec == null)
            return new HashSet<>();

        return sec.getKeys(false);
    }
}
