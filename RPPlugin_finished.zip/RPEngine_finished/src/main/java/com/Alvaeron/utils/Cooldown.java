package com.Alvaeron.utils;

import com.google.common.collect.HashBasedTable;
import com.google.common.collect.Table;
import org.bukkit.entity.Player;

public class Cooldown {

    private static final Table<String, String, Long> cooldowns =
            HashBasedTable.<String, String, Long>create();

    public static long getCooldown(Player player, String key) {
        Long expire = cooldowns.get(player.getName(), key);
        return calculateRemainder(expire);
    }

    public static long setCooldown(Player player, String key, long delay) {
        Long expire = System.currentTimeMillis() + delay;
        cooldowns.put(player.getName(), key, expire);
        return calculateRemainder(expire);
    }

    public static boolean tryCooldown(Player player, String key, long delay) {
        if (getCooldown(player, key) <= 0L) {
            setCooldown(player, key, delay);
            return true;
        }
        return false;
    }

    private static long calculateRemainder(Long expireTime) {
        return (expireTime != null)
                ? (expireTime - System.currentTimeMillis())
                : Long.MIN_VALUE;
    }
}