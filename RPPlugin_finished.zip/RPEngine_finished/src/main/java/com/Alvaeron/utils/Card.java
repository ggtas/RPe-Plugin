/*     */ package com.Alvaeron.utils;
/*     */ 
/*     */ import com.Alvaeron.Engine;
/*     */ import com.Alvaeron.player.RoleplayPlayer;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import net.md_5.bungee.api.chat.BaseComponent;
import net.md_5.bungee.chat.ComponentSerializer;
import org.bukkit.Bukkit;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.entity.Player;
           import net.kyori.adventure.text.Component;
           import net.kyori.adventure.text.serializer.gson.GsonComponentSerializer;
            import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
/*     */ 
/*     */ public class Card
/*     */ {
/*     */   private Engine plugin;
/*     */   
/*     */   public Card(Engine plugin) {
/*  18 */     this.plugin = plugin;
/*     */   }
/*     */   
/*     */   public void sendCard(RoleplayPlayer rpp) {
/*  22 */     rpp.getPlayer().sendMessage(Lang.CARD_OWN.toString());
/*  23 */     rpp.getPlayer().sendMessage(Lang.CARD_CLICK_TO_EDIT_FIELDS.toString());
/*  24 */     sendJson(rpp.getPlayer(), "[\"\",{\"text\":\"" + Lang.CARD_FIELD_NAME.toString() + ": \",\"color\":\"green\",\"clickEvent\":{\"action\":\"suggest_command\",\"value\":\"/card name " + rpp.getName() + "\"},\"hoverEvent\":{\"action\":\"show_text\",\"value\":{\"text\":\"\",\"extra\":[{\"text\":\"" + Lang.CARD_CLICK_TO_EDIT.toString() + "\",\"color\":\"aqua\"}]}}},{\"text\":\"" + rpp.getName() + "\",\"color\":\"white\",\"clickEvent\":{\"action\":\"suggest_command\",\"value\":\"/card name " + rpp.getName() + "\"},\"hoverEvent\":{\"action\":\"show_text\",\"value\":{\"text\":\"\",\"extra\":[{\"text\":\"" + Lang.CARD_CLICK_TO_EDIT.toString() + "\",\"color\":\"aqua\"}]}}}]");
/*  25 */     sendJson(rpp.getPlayer(), "[\"\",{\"text\":\"" + Lang.CARD_FIELD_AGE.toString() + ": \",\"color\":\"green\",\"clickEvent\":{\"action\":\"suggest_command\",\"value\":\"/card age " + rpp.getAge() + "\"},\"hoverEvent\":{\"action\":\"show_text\",\"value\":{\"text\":\"\",\"extra\":[{\"text\":\"" + Lang.CARD_CLICK_TO_EDIT.toString() + "\",\"color\":\"aqua\"}]}}},{\"text\":\"" + rpp.getAge() + "\",\"color\":\"white\",\"clickEvent\":{\"action\":\"suggest_command\",\"value\":\"/card age " + rpp.getAge() + "\"},\"hoverEvent\":{\"action\":\"show_text\",\"value\":{\"text\":\"\",\"extra\":[{\"text\":\"" + Lang.CARD_CLICK_TO_EDIT.toString() + "\",\"color\":\"aqua\"}]}}}]");
/*  26 */     sendJson(rpp.getPlayer(), "[\"\",{\"text\":\"" + Lang.CARD_FIELD_GENDER.toString() + ": \",\"color\":\"green\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"/card gender\"},\"hoverEvent\":{\"action\":\"show_text\",\"value\":{\"text\":\"\",\"extra\":[{\"text\":\"" + Lang.CARD_CLICK_TO_EDIT.toString() + "\",\"color\":\"aqua\"}]}}},{\"text\":\"" + Lang.valueOf("CARD_FIELD_GENDER_" + rpp.getGender().name().toUpperCase()) + "\",\"color\":\"white\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"/card gender\"},\"hoverEvent\":{\"action\":\"show_text\",\"value\":{\"text\":\"\",\"extra\":[{\"text\":\"" + Lang.CARD_CLICK_TO_EDIT.toString() + "\",\"color\":\"aqua\"}]}}}]");
/*  27 */     String color = "white";
/*     */     try {
/*  29 */       ChatColor c = ChatColor.valueOf(this.plugin.getConfig().getString("Races." + rpp.getRace() + ".Color"));
/*  30 */       color = c.name().toLowerCase();
/*  31 */     } catch (Exception e) {
/*  32 */       color = "white";
/*     */     } 
/*  34 */     sendJson(rpp.getPlayer(), "[\"\",{\"text\":\"" + Lang.CARD_FIELD_RACE.toString() + ": \",\"color\":\"green\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"/card race\"},\"hoverEvent\":{\"action\":\"show_text\",\"value\":{\"text\":\"\",\"extra\":[{\"text\":\"" + Lang.CARD_CLICK_TO_EDIT.toString() + "\",\"color\":\"aqua\"}]}}},{\"text\":\"" + rpp.getRace() + "\",\"color\":\"" + color + "\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"/card race\"},\"hoverEvent\":{\"action\":\"show_text\",\"value\":{\"text\":\"\",\"extra\":[{\"text\":\"" + Lang.CARD_CLICK_TO_EDIT.toString() + "\",\"color\":\"aqua\"}]}}}]");
/*  35 */     sendJson(rpp.getPlayer(), "[\"\",{\"text\":\"" + Lang.CARD_FIELD_NATION.toString() + ": \",\"color\":\"green\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"/card nation\"},\"hoverEvent\":{\"action\":\"show_text\",\"value\":{\"text\":\"\",\"extra\":[{\"text\":\"" + Lang.CARD_CLICK_TO_EDIT.toString() + "\",\"color\":\"aqua\"}]}}},{\"text\":\"" + rpp.getNation() + "\",\"color\":\"white\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"/card nation\"},\"hoverEvent\":{\"action\":\"show_text\",\"value\":{\"text\":\"\",\"extra\":[{\"text\":\"" + Lang.CARD_CLICK_TO_EDIT.toString() + "\",\"color\":\"aqua\"}]}}}]");
/*  36 */     sendJson(rpp.getPlayer(), "[\"\",{\"text\":\"" + Lang.CARD_FIELD_DESC.toString() + ": \",\"color\":\"green\",\"clickEvent\":{\"action\":\"suggest_command\",\"value\":\"/card desc " + rpp.getDesc() + "\"},\"hoverEvent\":{\"action\":\"show_text\",\"value\":{\"text\":\"\",\"extra\":[{\"text\":\"" + Lang.CARD_CLICK_TO_EDIT.toString() + "\",\"color\":\"aqua\"}]}}},{\"text\":\"" + rpp.getDesc() + "\",\"color\":\"white\",\"clickEvent\":{\"action\":\"suggest_command\",\"value\":\"/card desc " + rpp.getDesc() + "\"},\"hoverEvent\":{\"action\":\"show_text\",\"value\":{\"text\":\"\",\"extra\":[{\"text\":\"" + Lang.CARD_CLICK_TO_EDIT.toString() + "\",\"color\":\"aqua\"}]}}}]");
/*  37 */     if (Engine.skillsEnabled)
/*  38 */       sendJson(rpp.getPlayer(), "[\"\",{\"text\":\"" + Lang.CARD_FIELD_SKILLS.toString() + ": \",\"color\":\"green\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"/card skills\"},\"hoverEvent\":{\"action\":\"show_text\",\"value\":{\"text\":\"\",\"extra\":[{\"text\":\"" + Lang.CARD_CLICK_TO_EDIT.toString() + "\",\"color\":\"aqua\"}]}}},{\"text\":\"" + String.join(", ", rpp.getSkills()) + "\",\"color\":\"white\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"/card skills\"},\"hoverEvent\":{\"action\":\"show_text\",\"value\":{\"text\":\"\",\"extra\":[{\"text\":\"" + Lang.CARD_CLICK_TO_EDIT.toString() + "\",\"color\":\"aqua\"}]}}}]"); 
/*     */   }
/*     */   
/*     */   public void sendCardOther(RoleplayPlayer rpp, Player reciever) {
/*  42 */     reciever.sendMessage(Lang.CARD_OTHERS.toString().replace("%p", rpp.getPlayer().getName()));
/*  43 */     reciever.sendMessage(ChatColor.GREEN + Lang.CARD_FIELD_NAME.toString() + ": " + ChatColor.WHITE + rpp.getName());
/*  44 */     reciever.sendMessage(ChatColor.GREEN + Lang.CARD_FIELD_AGE.toString() + ": " + ChatColor.WHITE + rpp.getAge());
/*  45 */     reciever.sendMessage(ChatColor.GREEN + Lang.CARD_FIELD_GENDER.toString() + ": " + ChatColor.WHITE + Lang.valueOf("CARD_FIELD_GENDER_" + rpp.getGender().getName().toUpperCase()).toString());
/*  46 */     reciever.sendMessage(ChatColor.GREEN + Lang.CARD_FIELD_RACE.toString() + ": " + ChatColor.WHITE + rpp.getRace());
/*  47 */     reciever.sendMessage(ChatColor.GREEN + Lang.CARD_FIELD_NAME.toString() + ": " + ChatColor.WHITE + rpp.getNation());
/*  48 */     reciever.sendMessage(ChatColor.GREEN + Lang.CARD_FIELD_DESC.toString() + ": " + ChatColor.WHITE + rpp.getDesc());
/*  49 */     if (Engine.skillsEnabled)
/*  50 */       reciever.sendMessage(ChatColor.GREEN + Lang.CARD_FIELD_SKILLS.toString() + ": " + ChatColor.WHITE + String.join(", ", rpp.getSkills())); 
/*     */   }
/*     */   
/*     */   public void sendGenderSelect(RoleplayPlayer rpp) {
/*  54 */     rpp.getPlayer().sendMessage(Lang.CARD_SELECT_GENDER.toString());
/*  55 */     sendJson(rpp.getPlayer(), "[\"\",{\"text\":\"" + Lang.CARD_FIELD_GENDER_MALE.toString() + "\",\"color\":\"blue\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"/card gender male\"},\"hoverEvent\":{\"action\":\"show_text\",\"value\":{\"text\":\"\",\"extra\":[{\"text\":\"" + Lang.CARD_CLICK_TO_GENDER.toString().replace("%g", Lang.CARD_FIELD_GENDER_MALE.toString()) + "\",\"color\":\"aqua\"}]}}}]");
/*  56 */     sendJson(rpp.getPlayer(), "[\"\",{\"text\":\"" + Lang.CARD_FIELD_GENDER_FEMALE.toString() + "\",\"color\":\"light_purple\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"/card gender female\"},\"hoverEvent\":{\"action\":\"show_text\",\"value\":{\"text\":\"\",\"extra\":[{\"text\":\"" + Lang.CARD_CLICK_TO_GENDER.toString().replace("%g", Lang.CARD_FIELD_GENDER_FEMALE.toString()) + "\",\"color\":\"aqua\"}]}}}]");
/*     */   }
/*     */   
/*     */   public void sendRaces(RoleplayPlayer rpp) {
/*  60 */     Set<String> races = this.plugin.getConfig().getConfigurationSection("Races").getKeys(false);
/*  61 */     rpp.getPlayer().sendMessage(Lang.CARD_SELECT_RACE.toString());
/*  62 */     for (String race : races) {
/*  63 */       sendJson(rpp.getPlayer(), "[\"\",{\"text\":\"" + race + "\",\"color\":\"" + this.plugin.getConfig().getString("Races." + race + ".Color").toLowerCase() + "\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"/card race " + race + "\"},\"hoverEvent\":{\"action\":\"show_text\",\"value\":{\"text\":\"\",\"extra\":[{\"text\":\"" + Lang.CARD_CLICK_TO_RACE.toString().replace("%r", race) + "\",\"color\":\"aqua\"}]}}}]");
/*     */     }
/*     */   }
/*     */   
/*     */   public void sendNations(RoleplayPlayer rpp) {
/*  68 */     Set<String> nations = this.plugin.getConfig().getConfigurationSection("Nations").getKeys(false);
/*  69 */     rpp.getPlayer().sendMessage(Lang.CARD_SELECT_NATION.toString());
/*  70 */     for (String nation : nations)
/*  71 */       sendJson(rpp.getPlayer(), "[\"\",{\"text\":\"" + nation + "\",\"color\":\"white\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"/card nation " + nation + "\"},\"hoverEvent\":{\"action\":\"show_text\",\"value\":{\"text\":\"\",\"extra\":[{\"text\":\"" + Lang.CARD_CLICK_TO_NATION.toString().replace("%n", nation) + "\",\"color\":\"aqua\"}]}}}]"); 
/*     */   }
/*     */   
/*     */   public void clickToSendCard(Player p) {
/*  75 */     sendJson(p, "[\"\",{\"text\":\"" + Lang.CARD_CLICK_TO_SHOW.toString() + "\",\"color\":\"aqua\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"/card\"},\"hoverEvent\":{\"action\":\"show_text\",\"value\":{\"text\":\"\",\"extra\":[{\"text\":\"" + Lang.CARD_CLICK_TO_SHOW.toString() + "\",\"color\":\"aqua\"}]}}}]");
/*     */   }
/*     */
/*     */   
/*     */   public void sendSkillActionSelect(Player p) {
/*  82 */     sendJson(p, "[\"\",{\"text\":\"Would you like to \",\"color\":\"white\"},{\"text\":\"ADD \",\"color\":\"green\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"/card skills add\"},\"hoverEvent\":{\"action\":\"show_text\",\"value\":{\"text\":\"\",\"extra\":[{\"text\":\"Click to add a skill\",\"color\":\"aqua\"}]}}},{\"text\":\"or \",\"color\":\"white\"},{\"text\":\"REMOVE \",\"color\":\"green\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"/card skills remove\"},\"hoverEvent\":{\"action\":\"show_text\",\"value\":{\"text\":\"\",\"extra\":[{\"text\":\"Click to remove a skill\",\"color\":\"aqua\"}]}}},{\"text\":\"a skill?\",\"color\":\"white\"}]");
/*     */   }
/*     */   
/*     */   public void sendAddSkills(RoleplayPlayer rpp) {
/*  86 */     if (!Engine.skillsEnabled) {
/*     */       return;
/*     */     }
/*  89 */     Set<String> availableSkills = new HashSet<>(this.plugin.getConfig().getStringList("Skills"));
/*  90 */     Set<String> availableLanguages = this.plugin.getConfig().getConfigurationSection("Languages").getKeys(false);
/*  91 */     availableSkills.addAll(availableLanguages);
/*  92 */     List<String> player_skills = rpp.getSkills();
/*  93 */     availableSkills.removeAll(player_skills);
/*     */ 
/*     */     
/*  96 */     if (availableSkills.isEmpty()) {
/*  97 */       rpp.getPlayer().sendMessage("No more skills available.");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 102 */     sendJson(rpp.getPlayer(), "[\"\", {\"text\":\"Select a skill to remove.\",\"color\":\"white\"}]");
/* 103 */     for (String skill : availableSkills) {
/* 104 */       sendJson(rpp.getPlayer(), "[\"\",{\"text\":\"" + skill + "\",\"color\":\"aqua\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"/card skills add " + skill + "\"},\"hoverEvent\":{\"action\":\"show_text\",\"value\":{\"text\":\"\",\"extra\":[{\"text\":\"Click to remove this skill\",\"color\":\"aqua\"}]}}}]");
/*     */     }
/*     */   }
/*     */   
/*     */   public void sendRemoveSkills(RoleplayPlayer rpp) {
/* 109 */     if (!Engine.skillsEnabled) {
/*     */       return;
/*     */     }
/* 112 */     List<String> player_skills = rpp.getSkills();
/*     */ 
/*     */     
/* 115 */     if (player_skills.isEmpty()) {
/* 116 */       rpp.getPlayer().sendMessage("You don't have any skills to remove.");
/*     */       
/*     */       return;
/*     */     } 
/*     */     }
/* 121 */

    public void sendJson(Player p, String json) {

        Component component = GsonComponentSerializer.gson().deserialize(json);

        String legacy = LegacyComponentSerializer.legacySection().serialize(component);

        p.sendMessage(legacy);
    }
/*     */ }



/* Location:              C:\Users\Anwender\Downloads\RPEngine-4.6_1.13.jar!\com\Alvaero\\utils\Card.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */