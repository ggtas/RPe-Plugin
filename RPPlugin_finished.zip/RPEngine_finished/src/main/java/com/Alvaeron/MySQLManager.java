package com.Alvaeron;
import java.sql.PreparedStatement;
import org.bukkit.Bukkit;

import com.Alvaeron.player.RoleplayPlayer;
import com.Alvaeron.utils.LetterRenderer;

import org.bukkit.entity.Player;
import org.bukkit.map.MapRenderer;

import java.sql.ResultSet;

import org.bukkit.map.MapView;

import java.io.File;
import java.sql.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.UUID;

public class MySQLManager {

    private final Engine plugin;
    private Connection connection;

    private String dbType = "sqlite";

    /* MySQL */
    private String host;
    private String port;
    private String database;
    private String user;
    private String password;

    private String tablePrefix = "rpen_";

    public MySQLManager(Engine plugin) {
        this.plugin = plugin;
    }

    /* ========================================================= */
    /* ENABLE / DISABLE                                          */
    /* ========================================================= */

    public void onEnable() {

        if (plugin.getConfig().contains("databasetype")) {
            dbType = plugin.getConfig().getString("databasetype", "sqlite");
        }

        if (plugin.getConfig().contains("table-prefix")) {
            tablePrefix = plugin.getConfig().getString("table-prefix", "rpen_");
        }

        if (dbType.equalsIgnoreCase("mysql")) {

            host = plugin.getConfig().getString("mysql.host");
            port = plugin.getConfig().getString("mysql.port");
            database = plugin.getConfig().getString("mysql.database");
            user = plugin.getConfig().getString("mysql.user");
            password = plugin.getConfig().getString("mysql.password");
        }

        connect();
        initTables();
    }

    public void onDisable() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /* ========================================================= */
    /* CONNECTION                                                */
    /* ========================================================= */

    private void connect() {

        try {

            if (connection != null && !connection.isClosed()) {
                return;
            }

            if (dbType.equalsIgnoreCase("mysql")) {

                connection = DriverManager.getConnection(
                        "jdbc:mysql://" + host + ":" + port + "/" + database + "?autoReconnect=true",
                        user,
                        password
                );

                plugin.getLogger().info("Connected to MySQL.");

            } else {

                Class.forName("org.sqlite.JDBC");

                File dbFile = new File(plugin.getDataFolder(), "data.db");

                connection = DriverManager.getConnection("jdbc:sqlite:" + dbFile);

                plugin.getLogger().info("Connected to SQLite.");
            }

        } catch (Exception e) {

            plugin.getLogger().log(Level.SEVERE, "Couldn't connect to database", e);
            Bukkit.getPluginManager().disablePlugin(plugin);
        }
    }

    public boolean isConnectionValid() {
        try {
            return connection != null && !connection.isClosed();
        } catch (SQLException e) {
            return false;
        }
    }

    public Connection getConnection() {
        return connection;
    }

    /* ========================================================= */
    /* TABLE INIT                                                */
    /* ========================================================= */

    public void initTables() {

        if (!isConnectionValid()) return;

        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {

            try (Statement st = connection.createStatement()) {

                st.executeUpdate(
                        "CREATE TABLE IF NOT EXISTS `" + tablePrefix + "Cards` (" +
                                "`UUID` VARCHAR(100) PRIMARY KEY," +
                                "`name` VARCHAR(100)," +
                                "`age` INT DEFAULT 0," +
                                "`desc` TEXT," +
                                "`skills` TEXT," +
                                "`lang` TEXT" +
                                ");"

                );


                st.executeUpdate(
                        "CREATE TABLE IF NOT EXISTS `" + tablePrefix + "Maps` (" +
                                "`ID` INTEGER PRIMARY KEY," +
                                "`message` TEXT" +
                                ");"
                );
                st.executeUpdate(
                        "CREATE TABLE IF NOT EXISTS rp_language_understanding (" +
                                "player_uuid TEXT, " +
                                "language TEXT, " +
                                "understanding REAL, " +
                                "PRIMARY KEY(player_uuid, language))"
                );

                ensureColumn("race", "TEXT DEFAULT 'NONE'");
                ensureColumn("nation", "TEXT DEFAULT 'NONE'");
                ensureColumn("desc", "TEXT DEFAULT 'NONE'");
                ensureColumn("age", "INTEGER DEFAULT 18");
                ensureColumn("gender", "TEXT DEFAULT 'NONE'");
                ensureColumn("lang","TEXT DEFAULT 'NONE'" );
                ensureColumn("skills","TEXT DEFAULT 'NONE'" );


            } catch (SQLException e) {
                e.printStackTrace();
            }

            for (String stat : Engine.getInstance().getConfig().getStringList("CardStats")) {

                try (PreparedStatement ps = connection.prepareStatement(
                        "ALTER TABLE " + tablePrefix + "Cards ADD COLUMN stat_" + stat + " INTEGER DEFAULT 0"
                )) {
                    ps.execute();
                } catch (Exception ignored) {
                    // Spalte existiert bereits → SQLite wirft Fehler → ignorieren
                }
            }
            try (Statement st = connection.createStatement()) {

                st.executeUpdate("ALTER TABLE " + tablePrefix + "Cards ADD COLUMN race TEXT DEFAULT 'NONE'");
            } catch (Exception ignored) {}

            try (Statement st = connection.createStatement()) {

                st.executeUpdate("ALTER TABLE " + tablePrefix + "Cards ADD COLUMN nation TEXT DEFAULT 'NONE'");
            } catch (Exception ignored) {}
            try (Statement st = connection.createStatement()) {

                st.executeUpdate("ALTER TABLE " + tablePrefix + "Cards ADD COLUMN gender TEXT DEFAULT 'NONE'");

            } catch (Exception ignored) {}
            try (Statement st = connection.createStatement()) {

                st.executeUpdate("ALTER TABLE rp_language_understanding ADD COLUMN language TEXT DEFAULT 'NONE'");

            } catch (Exception ignored) {}

        });

    }

    /* ========================================================= */
    /* SAFE QUERY HELPERS                                        */
    /* ========================================================= */

    public void asyncUpdate(String sql, SQLConsumer consumer) {

        if (!isConnectionValid()) return;

        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {

            try (PreparedStatement ps = connection.prepareStatement(sql)) {

                if (consumer != null) {
                    consumer.accept(ps);
                }

                ps.executeUpdate();

            } catch (SQLException e) {
                e.printStackTrace();
            }
        });
    }

    public void asyncQuery(String sql, SQLFunction consumer) {

        if (!isConnectionValid()) return;

        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {

            try (PreparedStatement ps = connection.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {

                if (consumer != null) {
                    consumer.accept(rs);
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }
        });
    }


    private void asyncQuery(String sql, SQLConsumer consumer) {

        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {

            try (PreparedStatement ps = connection.prepareStatement(sql)) {
                consumer.accept(ps);
            } catch (Exception e) {
                e.printStackTrace();
            }

        });
    }

    /* ========================================================= */
    /* INTERFACES                                                */
    /* ========================================================= */

    public interface SQLConsumer {
        void accept(PreparedStatement ps) throws SQLException;
    }

    public interface SQLFunction {
        void accept(ResultSet rs) throws SQLException;
    }

    public void createRoleplayPlayer(Player player) {

        if (player == null) return;

        UUID uuid = player.getUniqueId();

        RoleplayPlayer rp = Engine.manager.getPlayer(uuid);
        String ageStr = Engine.mm.getStringField(uuid, "age");

        if (ageStr != null) {
            try {
                rp.age = Integer.parseInt(ageStr);
            } catch (Exception ignored) {}
        }

        if (rp == null) {
            rp = new RoleplayPlayer(uuid);

            // 🔥 KRITISCH – Werte setzen
            rp.name = player.getName();
            rp.age = 18;
            rp.desc = "None";

            Engine.manager.addPlayer(rp);
        }

        asyncUpdate(
                "INSERT OR IGNORE INTO `" + tablePrefix + "Cards` (`UUID`,`name`,`age`,`desc`) VALUES (?,?,?,?)",
                ps -> {
                    ps.setString(1, uuid.toString());
                    ps.setString(2, player.getName());
                    ps.setInt(3, 18);
                    ps.setString(4, "None");
                }
        );
    }
    public void saveMap(int mapId, String message) {
        if (message == null) return;

        asyncUpdate(
                "INSERT OR REPLACE INTO " + tablePrefix + "maps (mapid, message) VALUES (?, ?)",
                ps -> {
                    ps.setInt(1, mapId);
                    ps.setString(2, message);
                }
        );
    }

    public void loadMap(MapView mapView) {

        if (mapView == null) return;

        asyncQuery(
                "SELECT message FROM `" + tablePrefix + "Maps` WHERE ID = ?",
                (PreparedStatement ps) -> {

                    ps.setInt(1, mapView.getId());

                    try (ResultSet rs = ps.executeQuery()) {

                        if (!rs.next()) return;

                        String message = rs.getString("message");
                        if (message == null) return;

                        Bukkit.getScheduler().runTask(plugin, () -> {

                            for (MapRenderer r : mapView.getRenderers()) {
                                mapView.removeRenderer(r);
                            }

                            mapView.addRenderer(new LetterRenderer(message));
                        });
                    }
                }
        );
    }

    public void removeMap(int mapId) {

        asyncQuery(
                "DELETE FROM `" + tablePrefix + "Maps` WHERE ID = ?",
                (PreparedStatement ps) -> {
                    ps.setInt(1, mapId);
                    ps.executeUpdate();
                }
        );
    }

    public void setStringField(UUID uuid, String column, String value) {

        String sql = "UPDATE `" + tablePrefix + "Cards` SET `" + column + "`=? WHERE `UUID`=?";

        try (PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setString(1, value);
            ps.setString(2, uuid.toString());

            int updated = ps.executeUpdate();

            Bukkit.getLogger().info("SQL UPDATE rows → " + updated);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public String getStringField(UUID uuid, String field) {

        try (PreparedStatement ps = connection.prepareStatement(
                "SELECT `" + field + "` FROM `" + tablePrefix + "Cards` WHERE UUID = ?")) {

            ps.setString(1, uuid.toString());

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {
                    return rs.getString(field);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    private void ensureColumn(String column, String sqlDef) {

        try (PreparedStatement ps =
                     connection.prepareStatement("PRAGMA table_info(" + tablePrefix + "Cards)");
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                if (rs.getString("name").equalsIgnoreCase(column))
                    return; // Spalte existiert → nichts tun
            }

            Bukkit.getLogger().info("Adding missing column: " + column);

            connection.prepareStatement(
                    "ALTER TABLE `" + tablePrefix + "Cards` ADD COLUMN `"
                            + column + "` " + sqlDef
            ).execute();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void loadRoleplayPlayer(RoleplayPlayer rpp) {

        UUID uuid = rpp.getUuid();

        try (PreparedStatement ps = connection.prepareStatement(
                "SELECT * FROM " + tablePrefix + "Cards WHERE UUID=?")) {

            ps.setString(1, uuid.toString());

            try (ResultSet rs = ps.executeQuery()) {

                if (!rs.next()) {
                    Bukkit.getLogger().info("[RPEngine] No DB entry for " + uuid);
                    return;
                }

                rpp.name = rs.getString("name");
                rpp.age = rs.getInt("age");
                rpp.desc = rs.getString("desc");

                rpp.race = rs.getString("race");
                rpp.nation = rs.getString("nation");

                String genderStr = rs.getString("gender");

                if (genderStr != null) {
                    try {
                        rpp.gender = RoleplayPlayer.Gender.valueOf(genderStr);
                    } catch (IllegalArgumentException ex) {
                        rpp.gender = RoleplayPlayer.Gender.NONE; // fallback falls DB Müll enthält
                    }
                }

                String skillString = rs.getString("skills");

                if (skillString != null && !skillString.isEmpty()) {
                    rpp.skills = new ArrayList<>(Arrays.asList(skillString.split(",")));
                }

                Bukkit.getLogger().info("[RPEngine] Loaded player data for " + uuid);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
